/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bankingsystem;

/**
 *
 * @author kmacr
 */

public class Account {
    // add your attributes here
    private int accountNumber;
    private String ownerFirstName;
    private String ownerLastName;
    private String socialSecurityNumber;
    private String pin;
    private Long balance;
    
    // add methods as getters and setters for attributes
    public void setAccountNumber(int accountNumber){
        this.accountNumber = accountNumber;
    }
    
    public void setOwnerFirstName(String ownerFirstName){
        this.ownerFirstName = ownerFirstName;
    }
    
    public void setOwnerLastName(String ownerLastName){
        this.ownerLastName = ownerLastName;
    }
    
    public void setSocialSecurityNumber(String socialSecurityNumber) {
        this.socialSecurityNumber = socialSecurityNumber;
    }
    
    public void setPin(String pin) {
        this.pin = pin;
    }
    
    public void setBalance(Long balance) {
        this.balance = balance;
    }
    
    public int getAccountNumber(){
        return accountNumber;
    }
    
    public String getOwnerFirstName() {
        return ownerFirstName;
    }
    
    public String getOwnerLastName() {
        return ownerLastName;
    }
    
    public String getSocialSecurityNumber() {
        return socialSecurityNumber;
    }
    
    public String getPin() {
        return pin;
    }
    
    
    public Long getBalance() {
        return balance;
    }
    
    
    
       
    public long deposit(long amount) {
        // implement deposit here
        //Takes a long as a parameter, adds the amount to the account balance and returns a ‘long’ 
        //representing the new account balance.
        long newAccountBalance = balance;                           
        newAccountBalance = newAccountBalance + amount;
        
        return newAccountBalance;
    }
    
  
    public long withdraw(long amount) {        
        // implement withdraw here
        long withdrawAccountBalance = balance;
        withdrawAccountBalance = withdrawAccountBalance - amount;
        
        
        return withdrawAccountBalance; // be sure to change this
    }
    
    
    public boolean isValidPIN(String enteredPin) {        
        // implement isValidPIN here
        
        for (int i = 0; i < enteredPin.length(); i++ ) {
            if (enteredPin.charAt(i) == (pin.charAt(i))) {     
                return true;
            }
        }
        
        return false;  
    }
    
     
    
    
    
    
    @Override // all objects have a toString method - this indicates you are providing your own version
    public String toString() {
        return "Account Number: " + accountNumber + "\nOwner First Name: " + ownerFirstName + 
                "\nOwner Last Name: " + ownerLastName + "\nOwner SSN: " + socialSecurityNumber +
                "\nPIN: " + pin + "\nBalance: " + balance;               
                 
    }               
}
