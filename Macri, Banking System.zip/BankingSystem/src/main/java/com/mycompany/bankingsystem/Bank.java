/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bankingsystem;

/**
 *
 * @author kmacr
 */
public class Bank {

    final static int MAX_ACCOUNTS = 100;

    Account[] accountArray = new Account[MAX_ACCOUNTS];

    public boolean addAccountToBank(Account account) {
        // implement addAccountToBank here
        if (account == null) {
            System.out.println("Account was null");
            return false;
        }

        for (int i = 0; i < accountArray.length; i++) {
            if (accountArray[i] == null) {
                accountArray[i] = account;
                System.out.println("Account added");
                return true;
            }
        }
        System.out.println("Account was not added Bank because it is full");
        return false; // be sure to change this as needed
    }

    public boolean removeAccountFromBank(Account account) {
        // implement removeAccountFromBank here'

        if (account == null) {
            System.out.println("Account was null");
            return false;
        }

        for (int i = 0; i < accountArray.length; i++) {
            if (accountArray[i] != null && accountArray[i].getAccountNumber() == account.getAccountNumber()) {
                accountArray[i] = null;
                return true;
            }
        }
        System.out.println("Account was not removed from Bank");
        return false;
    }

    public Account findAccount(int accountNumber) {

        for (int i = 0; i < accountArray.length; i++) {
            if (accountNumber == accountArray[i].getAccountNumber()) {
                return accountArray[i];
            }
        }
        System.out.println("Account not found");

        return null; // be sure to change this as needed
    }

    public boolean searchForAccount(int accountNumber) {
        for (int i = 0; i < accountArray.length; i++) {
            if (accountNumber == accountArray[i].getAccountNumber()) {
                return true;
            } else {
                System.out.println("Cannot find account number");
                return false;

            }


        }
        return false;

    }

    public void showAccounts() {
        for (int i = 0; i < accountArray.length; i++) {
            if (accountArray[i] != null) {
                System.out.println("Account Number: " + accountArray[i].getAccountNumber());
                System.out.println("Owner First Name: " + accountArray[i].getOwnerFirstName());
                System.out.println("Owner Last Name: " + accountArray[i].getOwnerLastName());
                System.out.println("Social Security Number: " + accountArray[i].getSocialSecurityNumber());
                System.out.println("Pin: " + accountArray[i].getPin());
                System.out.println("Balance: " + accountArray[i].getBalance());
            }
        }
    }

    public void addMonthlyInterest(double percent) {

        // EXTRA CREDIT
    }

}
