/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.bankingsystem;

/**
 *Need to create a unified banking system. There needs to be a display with 11 options and the ability to do 
 * the following: open account, close account, get account info, change pin, deposit, withdraw, transfer.  
 * 
 *Author: Kyle Macri
 *macrik@merrimack.edu
 *CSC 6001 - Foundations of Programming 1
 *Programming project #7
 */

import static com.mycompany.bankingsystem.BankUtility.generateRandomInteger;
import java.util.Scanner;
import java.util.Random;

public class BankManager {

    public static void main(String args[]) {

        
        Bank firstBank = new Bank();

        Scanner in = new Scanner(System.in);
        int menuSelection;
        do {
            do {
                System.out.println("");
                System.out.println("What do you want to do?");
                System.out.println("1. Open an account");
                System.out.println("2. Get account information and balance");
                System.out.println("3. Change PIN");
                System.out.println("4. Deposit money in account");
                System.out.println("5. Transfer money between accounts");
                System.out.println("6. Withdraw money from account");
                System.out.println("7. ATM withdrawal");
                System.out.println("8. Deposit change");
                System.out.println("9. Close an account");
                System.out.println("10. Add monthly interest to all accounts");
                System.out.println("11. End Program");

                System.out.print("Enter a number: ");
                menuSelection = in.nextInt();
                if (menuSelection < 1 || menuSelection > 11) {
                    System.out.println("Invalid Choice");
                    System.out.println();
                    System.out.println();
                }

            } while (menuSelection < 1 || menuSelection > 11);

            if (menuSelection == 1) {
               
                //Generate random integer in range, change it to a string and set it to account number. 
                int randomAccountNumberAsInt = generateRandomInteger(10000000, 99999999);
                String finalAccountNumberAsString =  Integer.toString(randomAccountNumberAsInt);

                int finalAccountNumberAsInt = Integer.parseInt(finalAccountNumberAsString);

                //Create Account object called newAccount. 
                Account newAccount = new Account();

                //Sets first name
                System.out.println("Enter Account Owners First Name: ");
                Scanner firstNameScanner = new Scanner(System.in);
                String newFirstName = firstNameScanner.nextLine();
                newAccount.setOwnerFirstName(newFirstName);

                //sets last name
                System.out.println("Enter Account Owners Last Name: ");
                Scanner lastNameScanner = new Scanner(System.in);
                String newLastName = lastNameScanner.nextLine();
                newAccount.setOwnerLastName(newLastName);

                //Sets Social
                System.out.println("Enter Account Owners SSN: ");
                Scanner socialScanner = new Scanner(System.in);
                String newSocial = socialScanner.nextLine();
                if (newSocial.length() == 9 ) {
                    newAccount.setSocialSecurityNumber(newSocial);
                }
                else {
                    System.out.println("SSN must be 9 digits");
                    return;
                }
                

                //Sets account numnber as random integer. 
                newAccount.setAccountNumber(finalAccountNumberAsInt);

                //Sets pin                
                int randomPIN = generateRandomInteger(1000, 9999);
                String newPIN = Integer.toString(randomPIN);
                newAccount.setPin(newPIN);
               
                //Sets Balance to 0
                newAccount.setBalance(0L);

                //add account to bank. 
                firstBank.addAccountToBank(newAccount);

                //print out contents of bank
                System.out.println("");
                firstBank.showAccounts();

            } else if (menuSelection == 2) {

                //Prompt enter account number
                System.out.println("Enter account number");
                Scanner accountScanner = new Scanner(System.in);
                int accountNumberEnteredInt = accountScanner.nextInt();
                
                //Check the all the accounts and select the account with the matching account number. 
                if (firstBank.searchForAccount(accountNumberEnteredInt) == true) {
                    System.out.println("account found");

                } else {
                    System.out.println("account not found");
                }
                
                //Prompt user for a pin 
                System.out.println("Enter PIN: ");
                Scanner pinScanner = new Scanner(System.in);
                String enteredPIN = pinScanner.nextLine();
                
                
                //Find the account that matched the account number entered by the user. 
                //If the entered PIN matches the PIN from findAccount, print out the account information 
                Account newAccount = firstBank.findAccount(accountNumberEnteredInt);
                
                if (newAccount.isValidPIN(enteredPIN) == true) {
                    System.out.println("Correct PIN");
                    System.out.println("");
                    System.out.println("Account Number: " + newAccount.getAccountNumber());
                    System.out.println("Owner First Name: " + newAccount.getOwnerFirstName());
                    System.out.println("Owner Last Name: " + newAccount.getOwnerLastName());
                    System.out.println("Social Security Number: " + newAccount.getSocialSecurityNumber());
                    System.out.println("Pin: " + newAccount.getPin());
                    System.out.println("Balance: " + newAccount.getBalance());
                    
                }
                
              
                    
                  

                

                
            } else if (menuSelection == 3) {
                //change PIN
                //Prompts user to enter accout number
                System.out.println("Enter account number");
                Scanner accountScanner = new Scanner(System.in);
                int accountNumberEnteredInt = accountScanner.nextInt();
                
                
                //Prompt user for a pin 
                System.out.println("Enter PIN: ");
                Scanner pinScanner = new Scanner(System.in);
                String enteredPIN = pinScanner.nextLine();
                
                
                //Check to see if account number and pin are valid 
                if (firstBank.searchForAccount(accountNumberEnteredInt) == true) {
                    System.out.println("account found");

                } else {
                    System.out.println("account not found");
                }
                
                //get the account for the PIN entered
                Account newAccount = firstBank.findAccount(accountNumberEnteredInt);
                
                //if PIN is correct, prompt user for new PIN
                if (newAccount.isValidPIN(enteredPIN) == true) {
                    //prompt user to enter a new PIN
                    System.out.println("Enter new PIN: ");
                    Scanner newPinScanner = new Scanner(System.in);
                    String firstNewPIN = newPinScanner.nextLine();
                    
                    System.out.println("Enter new PIN again: ");
                    Scanner nextPinScanner = new Scanner(System.in);
                    String secondNewPIN = nextPinScanner.nextLine();
                    
                    //Update PIN to new PIN
                    if (firstNewPIN.equals(secondNewPIN)) {
                        newAccount.setPin(firstNewPIN);
                        System.out.println("PIN updated");
                        System.out.println(newAccount.getPin());
                    }
                    else {
                        System.out.println("PINS do not match, try again");
                    }
                    
                }
                        

            } else if (menuSelection == 4) {
                //Deposit
                //Prompt user for account number and PIN
                System.out.println("Enter account number");
                Scanner accountScanner = new Scanner(System.in);
                int accountNumberEnteredInt = accountScanner.nextInt();
                
                
                //Prompt user for a pin 
                System.out.println("Enter PIN: ");
                Scanner pinScanner = new Scanner(System.in);
                String enteredPIN = pinScanner.nextLine();
                
                //Check to see if account number and pin are valid 
                if (firstBank.searchForAccount(accountNumberEnteredInt) == true) {
                    System.out.println("account found");

                } else {
                    System.out.println("account not found");
                }
                
                //newAccount is the Account object of the entered pin. 
                Account newAccount = firstBank.findAccount(accountNumberEnteredInt);
                
                //Is PIN valid
                if (newAccount.isValidPIN(enteredPIN) == true) {
                    //Prompt user to enter the dollar/cents
                    System.out.println("Enter amount to deposit in dollars and cents: ");
                    Scanner moneyScanner = new Scanner(System.in);
                    double depositAmount = moneyScanner.nextDouble();
                    if (depositAmount <= 0) {
                        System.out.println("Amount cannot be negative.");
                    }
                    //convert the amount entered to a long, and call deposit method on the account
                    else {
                        long longValue = (long)depositAmount;
                        long newBalance = newAccount.deposit(longValue);
                        newAccount.setBalance(newBalance);
                        System.out.println("New Balance" + newAccount.getBalance());
                    }
                }
                
                
                
                

            } else if (menuSelection == 5) {
                //Transfer
                //Prompt user to enter their account number
                System.out.println("Account to Transfer From: ");
                System.out.println("Enter account number");
                Scanner accountScanner = new Scanner(System.in);
                int accountNumberEnteredInt = accountScanner.nextInt();
                
                //Prompt for PIN of account to tranfer from 
                System.out.println("Enter PIN: ");
                Scanner pinScanner = new Scanner(System.in);
                String enteredPIN = pinScanner.nextLine();
                
                //Account number to tranfer to
                System.out.println("Account to Transfer to: ");
                System.out.println("Enter account number");
                Scanner transferToScanner = new Scanner(System.in);
                int transferToAccountNumber = accountScanner.nextInt();
                
                //Prompt for PIN of trasnfer to account
                System.out.println("Enter PIN: ");
                Scanner transferToPINScanner = new Scanner(System.in);
                String transferedToPIN = pinScanner.nextLine();
                
                //Check for transfer from Account
                if (firstBank.searchForAccount(accountNumberEnteredInt) == true) {
                    System.out.println("Transfer From Account Found");

                } else {
                    System.out.println("Transfer From Account not found");
                }
                

                
                //Transfer to and from accounts
                Account transferFromAccount = firstBank.findAccount(accountNumberEnteredInt);
                Account transferToAccount = firstBank.findAccount(transferToAccountNumber);
                
                //If both pins match...
                if (transferFromAccount.isValidPIN(enteredPIN) == true 
                        && transferToAccount.isValidPIN(transferedToPIN) == true) {
                    
                    System.out.println("Enter amount to deposit in dollars and cents: ");
                    Scanner moneyScanner = new Scanner(System.in);
                    double transferAmount = moneyScanner.nextDouble();
                    
                
                    if (transferAmount <= 0) {
                        System.out.println("Amount cannot be negative.");
                }
                    else {
                        //add the amount to the transfer to account
                        long longValue = (long)transferAmount;
                        long newBalance = transferToAccount.deposit(longValue);
                        transferToAccount.setBalance(newBalance);
                        
                        long withdrawLong = (long)transferAmount;
                        long newWithdrawBalance = transferFromAccount.withdraw(withdrawLong);
                        transferFromAccount.setBalance(newWithdrawBalance);
                        
                        System.out.println("New Balance of Account number " + transferFromAccount.getAccountNumber() + " is " + transferFromAccount.getBalance());
                        System.out.println("New Balance of Account number " + transferToAccount.getAccountNumber() + " is " + transferToAccount.getBalance());
                        
                    }
                }
                

            } else if (menuSelection == 6) {
                //withdraw money
                //prompt enter account number and pin 
                
                System.out.println("Enter account number");
                Scanner accountScanner = new Scanner(System.in);
                int accountNumberEnteredInt = accountScanner.nextInt();
                
                
                //Prompt user for a pin 
                System.out.println("Enter PIN: ");
                Scanner pinScanner = new Scanner(System.in);
                String enteredPIN = pinScanner.nextLine();
                
                //Check to see if account number and pin are valid 
                if (firstBank.searchForAccount(accountNumberEnteredInt) == true) {
                    System.out.println("account found");

                } else {
                    System.out.println("account not found");
                }
                
                Account newAccount = firstBank.findAccount(accountNumberEnteredInt);
                
                //if PIN is valid, withdraw money
                if (newAccount.isValidPIN(enteredPIN) == true) {
                    //Prompt user to enter the dollar/cents
                    System.out.println("Enter amount to withdraw in dollars and cents: ");
                    Scanner moneyScanner = new Scanner(System.in);
                    double withdrawAmount = moneyScanner.nextDouble();
                    if (withdrawAmount <= 0) {
                        System.out.println("Amount cannot be negative.");
                    }
                    //convert the amount entered to a long, and call withdraw method on the account
                    else {
                        long longValue = (long)withdrawAmount;
                        long newBalance = newAccount.withdraw(longValue);
                        newAccount.setBalance(newBalance);
                        System.out.println("New Balance " + newAccount.getBalance());
                    }
                }
                    
                
                
                
                

            } else if (menuSelection == 7) {
                //withdraw money ATM
                //prompt enter account number and pin 
                
                System.out.println("Enter account number");
                Scanner accountScanner = new Scanner(System.in);
                int accountNumberEnteredInt = accountScanner.nextInt();
                
                
                //Prompt user for a pin 
                System.out.println("Enter PIN: ");
                Scanner pinScanner = new Scanner(System.in);
                String enteredPIN = pinScanner.nextLine();
                
                //Check to see if account number and pin are valid 
                if (firstBank.searchForAccount(accountNumberEnteredInt) == true) {
                    System.out.println("account found");

                } else {
                    System.out.println("account not found");
                }
                
                Account newAccount = firstBank.findAccount(accountNumberEnteredInt);
                
                //if PIN is valid, withdraw money
                if (newAccount.isValidPIN(enteredPIN) == true) {
                    //Prompt user to enter the dollar/cents
                    System.out.println("Enter amount to withdraw in in multiples of 5, limit $1000: ");
                    Scanner moneyScanner = new Scanner(System.in);
                    double withdrawAmount = moneyScanner.nextDouble();
                    if (withdrawAmount <= 0 || withdrawAmount % 5 != 0) {
                        System.out.println("Amount cannot be negative and needs to be a multiple of 5");
                    }
                    //convert the amount entered to a long, and call withdraw method on the account
                    else {
                        long longValue = (long)withdrawAmount;
                        long newBalance = newAccount.withdraw(longValue);
                        newAccount.setBalance(newBalance);
                        System.out.println("New Balance " + newAccount.getBalance());
                        if (withdrawAmount % 20 == 0) {
                            System.out.println("The number of 20 dollar bills is: " + withdrawAmount/20);
                        }
                        else {
                            double amountAfterTwenty = withdrawAmount % 20 ;
                            double amountForFive = amountAfterTwenty % 10;
                            if (amountAfterTwenty % 10 == 0) {
                                System.out.println("The number of 10 dollar bills is: " + amountAfterTwenty/10);
                            }
                            if (amountForFive % 5 == 0) {
                                System.out.println("The number of 5 dollar bills is: " + amountAfterTwenty/5);
                            }
                        }
                    }
                }
                
                

            } else if (menuSelection == 8) {
                //Deposit change into account 
                //prompt enter account number and pin 
                
                System.out.println("Enter account number");
                Scanner accountScanner = new Scanner(System.in);
                int accountNumberEnteredInt = accountScanner.nextInt();
                
                
                //Prompt user for a pin 
                System.out.println("Enter PIN: ");
                Scanner pinScanner = new Scanner(System.in);
                String enteredPIN = pinScanner.nextLine();
                
                //Check to see if account number and pin are valid 
                if (firstBank.searchForAccount(accountNumberEnteredInt) == true) {
                    System.out.println("account found");

                } else {
                    System.out.println("account not found");
                }
                
                Account newAccount = firstBank.findAccount(accountNumberEnteredInt);
                
                //If PIN is valid 
                if (newAccount.isValidPIN(enteredPIN) == true) {
                    //Prompt user to deposit coins 
                    System.out.println("Deposit coins: ");
                    Scanner coinScanner = new Scanner(System.in);
                    String stringOfCoins = pinScanner.nextLine();
                    //check if there is an invalid coin type 
                    for (int i = 0; i < stringOfCoins.length(); i++) {
                        if (stringOfCoins.charAt(i) != 'P' && stringOfCoins.charAt(i) != 'N' && stringOfCoins.charAt(i) != 'D'
                                && stringOfCoins.charAt(i) != 'Q' && stringOfCoins.charAt(i) != 'H' && stringOfCoins.charAt(i) != 'W') {
                            System.out.println(stringOfCoins.charAt(i) + " is not a valid coin");
                        }
                        else {
                            System.out.println(stringOfCoins.charAt(i) + " is a valid coin");
                        }
                }
                    
                    long coinDepositAmount = CoinCollector.parseChange(stringOfCoins);
                    
                    long coinsInDollars = coinDepositAmount/100;
                    //Returns the new balance and stores it in newBalance
                    long newBalance = newAccount.deposit(coinsInDollars);
                    System.out.println("$" + coinsInDollars + " in coins deposited into account");
                    System.out.println("New Balance: " + newBalance);
                    
                }
                
                

            } else if (menuSelection == 9) {
                //Close account
                //prompt enter account number and pin 
                
                System.out.println("Enter account number");
                Scanner accountScanner = new Scanner(System.in);
                int accountNumberEnteredInt = accountScanner.nextInt();
                
                
                //Prompt user for a pin 
                System.out.println("Enter PIN: ");
                Scanner pinScanner = new Scanner(System.in);
                String enteredPIN = pinScanner.nextLine();
                
                //Check to see if account number and pin are valid 
                if (firstBank.searchForAccount(accountNumberEnteredInt) == true) {
                    System.out.println("account found");

                } else {
                    System.out.println("account not found");
                }
                
                Account newAccount = firstBank.findAccount(accountNumberEnteredInt);
                
                if (newAccount.isValidPIN(enteredPIN) == true) {
                    firstBank.removeAccountFromBank(newAccount);
                    int accountNumber = newAccount.getAccountNumber();
                    System.out.println("Account " + accountNumber + " was closed");
                    
                }
                
                
                

            } else if (menuSelection == 10) {

            } else if (menuSelection == 11) {
                //not necessary to have 

            }

        } while (menuSelection != 11);

    }

    public static Account promptForAccountNumberAndPIN(Bank bank) {

        // implement promptForAccountNumberAndPIN here
        return null; // be sure to change this as needed
    }
}
