/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bankingsystem;

import java.util.Scanner;
import java.util.Random;


/**
 *
 * @author kmacr
 */

public final class BankUtility {
    
    private BankUtility() {
        
    }
    
    static String promptUserForString(String prompt) {
        // implement promptUserForString here
        System.out.println(prompt);
        Scanner in = new Scanner(System.in);
        String userString = in.nextLine();
        
        return userString; // be sure to change this
    }         
    
    static double promptUserForPositiveNumber(String prompt) {
        
        // implement promptUserForPositiveNumber here
        System.out.println(prompt);
        Scanner in = new Scanner(System.in);
        Double userDouble = in.nextDouble();
        while (userDouble <= 0) {
            System.out.println("Amount cannot be negative. Try again");            
        }
        
        return userDouble; // be sure to change this
    }    
    
    //**fix
    static int generateRandomInteger(int min, int max) {
        // implement generateRandomInteger here
        Random random = new Random();
        int randomInt = min + random.nextInt((max - min) +1);  
        
        
        return randomInt; // be sure to change as needed
    }     
    static long convertFromDollarsToCents(double amount) {        
        // implement convertFromDollarsToCents here 
        double amountInCents = amount * 100;
        long centsAsLong = (long) amountInCents;     //Not sure if this works. 
        
                
        
        return centsAsLong; // be sure to change as needed
    }     
    
    /**
     * Checks if a given string is a number (long)
     * This does NOT handle decimals.
     * 
     * YOU DO NOT NEED TO CHANGE THIS METHOD
     * THIS IS FREE FOR YOU TO USE AS NEEDED
     * 
     * @param numberToCheck String to check
     * @return true if the String is a number, false otherwise
     */
    static boolean isNumeric(String numberToCheck) {        
        if (numberToCheck == null) {
            return false;
        }
        try {
            Long.parseLong(numberToCheck);
            return true; // if we reach this line, then no exception thrown so mustbe a number
            
        } catch (NumberFormatException nfe) {
            System.out.println(numberToCheck + " is not a number.");
            return false; // the number could not be parsed
        }        
    }       
}