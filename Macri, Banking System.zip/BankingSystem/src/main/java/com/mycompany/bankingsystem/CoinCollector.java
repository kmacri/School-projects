/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bankingsystem;

/**
 *
 * @author kmacr
 */
public final class CoinCollector {

    // private constructor so you cannot instantiate this class
    private CoinCollector() {

    }

    public static long parseChange(String coins) {
        long total = 0;
        for (int i = 0; i < coins.length(); i++) {
            if (coins.charAt(i) == 'P') {
                total = total + 1;
            } else if (coins.charAt(i) == 'N') {
                total = total + 5;
            } else if (coins.charAt(i) == 'D') {
                total = total + 10;
            } else if (coins.charAt(i) == 'Q') {
                total = total + 25;
            } else if (coins.charAt(i) == 'H') {
                total = total + 50;
            } else if (coins.charAt(i) == 'W') {
                total = total + 100;
            }
            

        }
        return total;
    }
}
