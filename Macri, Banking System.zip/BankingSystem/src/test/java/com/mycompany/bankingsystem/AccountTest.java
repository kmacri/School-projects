/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.bankingsystem;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author kmacr
 */
public class AccountTest {
    
    public AccountTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of setAccountNumber method, of class Account.
     */

    /**
     * Test of deposit method, of class Account.
     */
    @Test
    public void testDeposit() {
        System.out.println("deposit");
        long amount = 100L;
        Account instance = new Account();
        instance.setBalance(25L);
        long expResult = 125L;
        long result = instance.deposit(amount);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testDepositTwo() {
        System.out.println("deposit");
        long amount = 200L;
        Account instance = new Account();
        instance.setBalance(10L);
        long expResult = 210L;
        long result = instance.deposit(amount);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of withdraw method, of class Account.
     */
    @Test
    public void testWithdraw() {
        System.out.println("withdraw");
        long amount = 50L;
        Account instance = new Account();
        instance.setBalance(100L);
        long expResult = 50L;
        long result = instance.withdraw(amount);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testWithdrawTwo() {
        System.out.println("withdraw");
        long amount = 50L;
        Account instance = new Account();
        instance.setBalance(200L);
        long expResult = 150L;
        long result = instance.withdraw(amount);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of isValidPIN method, of class Account.
     */
    @Test
    public void testIsValidPIN() {
        System.out.println("isValidPIN");
        String enteredPin = "";
        Account instance = new Account();
        boolean expResult = false;
        boolean result = instance.isValidPIN(enteredPin);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testIsValidPINTwo() {
        System.out.println("isValidPIN");
        String enteredPin = "9555";
        Account instance = new Account();
        instance.setPin("9555");
        boolean expResult = true;
        boolean result = instance.isValidPIN(enteredPin);
        assertEquals(expResult, result);
        
    }

   
    
    
    
}
