/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.bankingsystem;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author kmacr
 */
public class BankTest {
    
    public BankTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of addAccountToBank method, of class Bank.
     */
    @Test
    public void testAddAccountToBank() {
        System.out.println("addAccountToBank");
        Account account = new Account();
        Bank instance = new Bank();
        boolean expResult = true;
        boolean result = instance.addAccountToBank(account);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testAddAccountToBankTwo() {
        System.out.println("addAccountToBank");
        Account account = new Account();
        Bank instance = new Bank();
        boolean expResult = true;
        boolean result = instance.addAccountToBank(account);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of removeAccountFromBank method, of class Bank.
     */
    @Test
    public void testRemoveAccountFromBank() {
        System.out.println("removeAccountFromBank");
        Account account = null;
        Bank instance = new Bank();
        boolean expResult = false;
        boolean result = instance.removeAccountFromBank(account);
        assertEquals(expResult, result);
        
    }
    
    public void testRemoveAccountFromBanktwo() {
        System.out.println("removeAccountFromBank");
        Account account = null;
        Bank instance = new Bank();
        boolean expResult = false;
        boolean result = instance.removeAccountFromBank(account);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of findAccount method, of class Bank.
     */
    @Test
    public void testFindAccount() {
        System.out.println("findAccount");
        int accountNumber = 1;
        Bank instance = new Bank();
        Account account = new Account();
        account.setAccountNumber(1);
        instance.addAccountToBank(account);
        Account expResult = account;
        Account result = instance.findAccount(accountNumber);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testFindAccountTwo() {
        System.out.println("findAccount");
        int accountNumber = 2;
        Bank instance = new Bank();
        Account account = new Account();
        account.setAccountNumber(2);
        instance.addAccountToBank(account);
        Account expResult = account;
        Account result = instance.findAccount(accountNumber);
        assertEquals(expResult, result);
        
    }

   

    
    
}
