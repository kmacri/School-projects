/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.bankingsystem;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author kmacr
 */
public class BankUtilityTest {
    
    public BankUtilityTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    
    @Test
    public void testGenerateRandomInteger() {
        System.out.println("generateRandomInteger");
        int min = 7;
        int max = 7;
        int expResult = 7;
        int result = BankUtility.generateRandomInteger(min, max);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testGenerateRandomIntegerTwo() {
        System.out.println("generateRandomInteger");
        int min = 100;
        int max = 100;
        int expResult = 100;
        int result = BankUtility.generateRandomInteger(min, max);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of convertFromDollarsToCents method, of class BankUtility.
     */
    @Test
    public void testConvertFromDollarsToCents() {
        System.out.println("convertFromDollarsToCents");
        double amount = 5.5;
        long expResult = 550L;
        long result = BankUtility.convertFromDollarsToCents(amount);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testConvertFromDollarsToCentsTwo() {
        System.out.println("convertFromDollarsToCents");
        double amount = 6.6;
        long expResult = 660L;
        long result = BankUtility.convertFromDollarsToCents(amount);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of isNumeric method, of class BankUtility.
     */
    @Test
    public void testIsNumeric() {
        System.out.println("isNumeric");
        String numberToCheck = "This String";
        boolean expResult = false;
        boolean result = BankUtility.isNumeric(numberToCheck);
        assertEquals(expResult, result);
        
    }
    
    public void testIsNumericTwo() {
        System.out.println("isNumeric");
        String numberToCheck = "111";
        boolean expResult = true;
        boolean result = BankUtility.isNumeric(numberToCheck);
        assertEquals(expResult, result);
        
    }
    
}
