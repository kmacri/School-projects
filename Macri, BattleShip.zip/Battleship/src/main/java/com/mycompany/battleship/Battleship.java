/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.battleship;

//package edu.merrimack.fop1.week5; // optionally add a package
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/*
 *This program creats a game of battleship that takes user coordinates and returns an upadated board.
 *Author: Kyle Macri
 *macrik@merrimack.edu
 *CSC 6001 - Foundations of Programming 1
 *Programming project #5
 */
public class Battleship {

    // These are 'global' constants in that they can be used anywhere in your code
    // without passing them as arguments
    static final int NUM_COLUMNS = 10;
    static final int NUM_ROWS = 10;
    static final int NUM_SHIPS = 5;

    public static void main(String args[]) {
        // main method goes here 
        // call setupBoard, retuns 10x10 array, store in main as char array
        //char[][] board = new char[NUM_COLUMNS][NUM_ROWS]; perfrom in setupBoard
        char[][] mainBoard;
        mainBoard = setupBoard();
        drawBoard(mainBoard);         //displays the 10x10 array with 5 ships

        do {                          //do the following while boolean == false  
            Scanner in = new Scanner(System.in);
            int column;
            int row;
            do {
                System.out.println("Enter a column coodinate: ");       //do I want this in the loop??
                column = in.nextInt();
                if (column > 9 || column < 0) {
                    System.out.println("Invalid column");
                }

                System.out.println("Enter a row coodinate: ");
                row = in.nextInt();
                if (row > 9 || row < 0) {
                    System.out.println("Invalid row");
                }

            } while (!(column >= 0 && row >= 0 && column <   10 && row < 10));

            checkHitOrMiss(mainBoard, column, row);
            drawBoard(mainBoard);
        } while (isGameOver(mainBoard) == false);
        System.out.println("GameOver");

        //loop (until game over)
        //ask user for x and y coordinates
        //call hit or miss with x and y coordinates and the board (pass mainBoard, x, y )
        //Call isGameOver, are all of the 'S' gone
    }

    public static void drawBoard(char[][] board) {
        // implement drawBoard here
        //in main im pass mainBoard to drawBoard
        //for loop to print out all elements of board array
        for (int i = 0; i < NUM_COLUMNS; i++) {
            //for (int j = 0; j < NUM_ROWS; j++) {
            System.out.println(board[i]);
        }

        //}
    }

    public static String checkHitOrMiss(char[][] board, int column, int row) {
        // implement checkHitOrMiss here
        for (int i = 0; i < NUM_COLUMNS; i++) {             // ** need a do while loop?
            for (int j = 0; j < NUM_ROWS; j++) {
                if (board[row][column] == 'S') {
                    board[row][column] = 'X';              // if coordinates equal S, update with X and print hit
                    System.out.println("HIT");
                    return "hit";                                  //*** only break from the second loop?

                } else if (board[row][column] == 'X') {      // if coordinates equal X,print hit
                    System.out.println("Hit");
                    return "Hit";
                } else {                              // else update empty char with 0 and print miss
                    board[row][column] = 'O';
                    System.out.println("Miss");
                    return "Miss";
                }
            }

        }
        return ""; // change this to return what the assignment specifies

    }

    public static char[][] setupBoard() {
        char[][] board = new char[NUM_COLUMNS][NUM_ROWS];
        // initialize all content to space ' '
        char space = ' ', hit = 'X', miss = 'O';
        for (int i = 0; i < NUM_COLUMNS; i++) {
            for (int j = 0; j < NUM_ROWS; j++) {
                board[i][j] = space;
            }
        }

        for (int x = 0; x < NUM_SHIPS; x++) {     //put a for loop for number of ships 
            //gererate a random row, 
            //generate a random column
            //place ship at that random row and column 
            // implement setupBoard here
            int randomColumn = getRandomNumber(NUM_COLUMNS);
            int randomRow = getRandomNumber(NUM_ROWS);

            if (board[randomColumn][randomRow] != 'S') {
                board[randomColumn][randomRow] = 'S';

            }
        }

        return board;
    }

    public static boolean isGameOver(char[][] board) {
        // implement isGameOver here
        //end by counting number of x "hits" or if you find s you havnt finished sinking ships
        int shipsLeft = 0;
        for (int i = 0; i < NUM_COLUMNS; i++) {
            for (int j = 0; j < NUM_ROWS; j++) {
                if (board[i][j] == 'S') {
                    shipsLeft++;
                }

            }

        }

        if (shipsLeft > 0) {    //why is this if statment redundant? 
            return false;
        } else {
            return true;
        }

    }

    public static int getRandomNumber(int maxNumber) {
        Random random = new Random();
        return random.nextInt(maxNumber);
    }

}
