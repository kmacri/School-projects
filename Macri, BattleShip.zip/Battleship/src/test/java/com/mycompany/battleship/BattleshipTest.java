/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.battleship;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author kmacr
 */
public class BattleshipTest {
    
    public BattleshipTest() {
    }

    @org.junit.jupiter.api.BeforeAll
    public static void setUpClass() throws Exception {
    }

    @org.junit.jupiter.api.AfterAll
    public static void tearDownClass() throws Exception {
    }

    @org.junit.jupiter.api.BeforeEach
    public void setUp() throws Exception {
    }

    @org.junit.jupiter.api.AfterEach
    public void tearDown() throws Exception {
    }    


    /**
     * Test of main method, of class Battleship.
     */
    @org.junit.jupiter.api.Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Battleship.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of drawBoard method, of class Battleship.
     */
    @org.junit.jupiter.api.Test
    public void testDrawBoard() {
        System.out.println("drawBoard");
        char[][] board = null;
        Battleship.drawBoard(board);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkHitOrMiss method, of class Battleship.
     */
    @org.junit.jupiter.api.Test
    public void testCheckHitOrMiss() {
        System.out.println("checkHitOrMiss");
        char[][] board = null;
        int column = 0;
        int row = 0;
        String expResult = "";
        String result = Battleship.checkHitOrMiss(board, column, row);
        assertEquals(expResult, result);
    }

    /**
     * Test of setupBoard method, of class Battleship.
     */
    @org.junit.jupiter.api.Test
    public void testSetupBoard() {
        System.out.println("setupBoard");
        char[][] expResult = null;
        char[][] result = Battleship.setupBoard();
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of isGameOver method, of class Battleship.
     */
    @org.junit.jupiter.api.Test
    public void testIsGameOver() {
        System.out.println("isGameOver");
        char[][] board = null;
        boolean expResult = false;
        boolean result = Battleship.isGameOver(board);
        assertEquals(expResult, result);
    }

    /**
     * Test of getRandomNumber method, of class Battleship.
     */
    @org.junit.jupiter.api.Test
    public void testGetRandomNumber() {
        System.out.println("getRandomNumber");
        int maxNumber = 0;
        int expResult = 0;
        int result = Battleship.getRandomNumber(maxNumber);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }
    
}
