/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//import customer status at the top 
package edu.merrimack.fop2.mavenproject1;

/**
 *
 * @author kmacr
 */
public class CashRegister {
    //attributes
    private int number;
    private Customer customer; // if a customer is checking out at the register, this
                       //field will be set to that Customer, otherwise, this 
                       //will be null to indicate that the CashRegister is available to check out the next Customer in line
    private int scanEfficiency; 
    
    public CashRegister(int number, int scanEfficiency){
        this.number = number;
        this.scanEfficiency = scanEfficiency;
        //this.customer = null;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public int getNumber() {
        return number;
    }
    
    public void processCustomer(){
        

        if (customer.getStatus() == CustomerStatus.WAITING_IN_LINE)
        //if (customer.getStatus.equals("WAITNG_IN_LINE")){
            customer.setStatus(CustomerStatus.SCANNING_MERCHANDISE);
        
//handle the case if go below 0, if less than 0 set to 0
        else if (customer.getStatus() == CustomerStatus.SCANNING_MERCHANDISE){
            customer.setNumberOfItems(customer.getNumberOfItems() - scanEfficiency);
            
            if (customer.getNumberOfItems() > 0){
                //do nothing??
            }
            
            else if (customer.getNumberOfItems() <= 0){
                customer.setStatus(CustomerStatus.PROCESSING_PAYMENT);
                customer.setNumberOfItems(0);
            }
            
        }
        
        else if (customer.getStatus() == CustomerStatus.PROCESSING_PAYMENT){
            customer.setStatus(CustomerStatus.PURCHASE_COMPLETE);
            
        }
        
        else if (customer.getStatus() == CustomerStatus.PURCHASE_COMPLETE){
            //customer.setStatus(CustomerStatus.null);
            customer = null;
        }
                
        
    }
    
    
    
    
    @Override
    public String toString(){
        return "";
    }
    
    
    
}
