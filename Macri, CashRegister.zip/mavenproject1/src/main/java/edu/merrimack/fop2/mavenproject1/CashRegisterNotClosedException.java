/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.merrimack.fop2.mavenproject1;

/**
 *
 * @author kmacr
 */
public class CashRegisterNotClosedException extends Exception{
    public CashRegisterNotClosedException (String message) {
        super(message);
    
}
    
}
