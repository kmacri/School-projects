/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.merrimack.fop2.mavenproject1;

/**
 *
 * @author kmacr
 */
public class Customer {
    String name;
    CustomerStatus status;
    int numberOfItems;
    
    public Customer(String name, int numberOfItems){
        this.name = name;
        this.numberOfItems = numberOfItems;
        this.status = CustomerStatus.SHOPPING;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setStatus(CustomerStatus status) {
        this.status = status;
    }

    public void setNumberOfItems(int numberOfItems) {
        this.numberOfItems = numberOfItems;
    }

    public String getName() {
        return name;
    }

    public CustomerStatus getStatus() {
        return status;
    }

    public int getNumberOfItems() {
        return numberOfItems;
    }
    
    
    
    //*****************dont forget to update*****************
    @Override
    public String toString(){
        return "";
    }
    
    
    
}
