/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package edu.merrimack.fop2.mavenproject1;

/**
 *
 * @author kmacr
 */
public enum CustomerStatus {
    SHOPPING("Shopping"),
    WAITING_IN_LINE("Waiting in line"),
    SCANNING_MERCHANDISE("Scanning Merchandise"),
    PROCESSING_PAYMENT("Processing_Payment"),
    PURCHASE_COMPLETE("Purchase Complete");
    
    
    private final String CustomerStatus;

    
    CustomerStatus(String CustomerStatus){
        this.CustomerStatus = CustomerStatus;

    }
    
    
    public String getCustomerStatus() {
        return CustomerStatus;
    }
    
}
