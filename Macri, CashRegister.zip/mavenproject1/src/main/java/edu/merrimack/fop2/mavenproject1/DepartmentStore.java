/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.merrimack.fop2.mavenproject1;

/**
 *
 * @author kmacr
 */
public class DepartmentStore {

    private LinkedQueue<Customer> customerLine = new LinkedQueue();
    private LinkedList<CashRegister> cashRegisters = new LinkedList();
    int maximumCashRegisters;
    int scanEfficiency;

    //Constructor 
    public DepartmentStore(int maximumCashRegisters, int scanEfficiency) {
        this.maximumCashRegisters = maximumCashRegisters;
        this.scanEfficiency = scanEfficiency;
    }

    public LinkedQueue<Customer> getCustomerLine() {
        return customerLine;
    }

    public LinkedList<CashRegister> getCashRegisters() {
        return cashRegisters;
    }
    
    /**
     * inserts a new cashregister 
     * @throws CashRegisterNotOpenedException 
     */

    public void openCashRegister() throws CashRegisterNotOpenedException {
        if (cashRegisters.getLength() >= maximumCashRegisters) {
            throw new CashRegisterNotOpenedException("Max cash registers reached");
           
        } else {
            CashRegister newRegister = new CashRegister(cashRegisters.getLength()+1, scanEfficiency); //change numebr each time,  pass in scan efficiency, 
            //insert it into the list
            //parameters are index, item(cashRegister obj)
            //****index should be 0? or it doesnt matter because it will push the other objects down
            cashRegisters.insert(0, newRegister);
        }

    }
    
    /**
     * closes a cashregister unless there is no register to close
     * @throws CashRegisterNotClosedException 
     */

    public void closeCashRegister() throws CashRegisterNotClosedException {
        //iterate through all registers
        for (int i = 0; i < cashRegisters.getLength(); i++) {
            if (cashRegisters.getEntry(i).getCustomer() == null) {
                cashRegisters.remove(i);
            } else {
                throw new CashRegisterNotClosedException("CashRegister cannot be removed or there is no CashRegister to close");
            }
        }

    }
    /**
     * 
     * @return int representing the number of empty registers
     */
    
    public int howManyEmpty(){
        int count = 0;
        for (int i = 0; i < cashRegisters.getLength(); i++) { 
            if (cashRegisters.getEntry(i).getCustomer() == null){
                count++;
            }
            
        }
        return count;
    }
    
    /**
     * If there are no CashRegisters open and there are customers in line, then you must open a cash register
     */

    public void manageCashRegisters() {
        //If there are no CashRegisters open and there are customers in line, then you must open a cash register
        //Iterate throguh register list and check if any have customer set to null?
        //**************Implimenting opening register correctly??
        for (int i = 0; i < cashRegisters.getLength(); i++) {
            if (!customerLine.isEmpty() && cashRegisters.getEntry(i).getCustomer() != null) {
                try {
                    openCashRegister();
                } catch (CashRegisterNotOpenedException cr) {
                    System.out.println("oops" + cr.getMessage());
                }

            } //If the customer line has more than 3 Customers and 
            //you have more cash registers available, you must open a cash register
            //wont an exception be thrown, do I need an && in my 
            //what else would I do loop through registers to see if there is a customer?
            else if (customerLine.getLength() > 3) {
                try {
                    openCashRegister();

                } catch (CashRegisterNotOpenedException cr) {
                    System.out.println("oops" + cr.getMessage());
                }
            }
            //If the customer line is empty and there is more than one cash register 
            //without a Customer checking out, you must close ONE cash register
            //***Check this********
            else if(customerLine.isEmpty() && howManyEmpty() > 1 ){
                try{
                    closeCashRegister();
               }catch (CashRegisterNotClosedException no){
                    System.out.println("oops" + no.getMessage());
                }
                
            }

        }

    }

    //This method simply takes a Customer object, sets the status to ‘WAITING_IN_LINE’ 
    //and adds to the customer line (queue)
    public void addCustomerToLine(Customer customer) {
        customer.setStatus(CustomerStatus.WAITING_IN_LINE);
        customerLine.enqueue(customer);

    }
    
    /**
     * f the cash register does not have a Customer and the customerLine has a 
     * Customer waiting, the customer should be taken out of the line and 
     * assigned to the CashRegisterOtherwise, if the CashRegister already
     * has a customer present, the ‘processCustomer’ method of that Customer should
     * be called to continue processing that Customer’s checkout
     */

    public void processCustomers() {
        for (int i = 0; i < cashRegisters.getLength(); i++) {
            //get front??******
            //isEmpty
            CashRegister register = cashRegisters.getEntry(i);
            if (register.getCustomer() == null ){
                //add customer to the register
                //if there is a customer there, process the customer 
                try{
                    Customer customerWaiting = customerLine.dequeue();
                    //assign customer waitint to a register
                    register.setCustomer(customerWaiting);
                }
                catch(EmptyQueueException eq){
                    System.out.println("oops" + eq.getMessage());
                }
            }else{
                register.processCustomer();
            }
                
            }
                

    }

}
