/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.merrimack.fop2.mavenproject1;

/**
 *
 * @author kmacr
 */
public class LinkedStack<T> implements StackInterface<T> {

    //LinkedStack attributes:
    //Represents the top of the stack
    private Node<T> top;

    /**
     * Sets top of the stack to null as default
     */
    public LinkedStack() {
        top = null;
    }

    /**
     *
     * @return true if that stack is empty, false otherwise
     */
    @Override
    public boolean isEmpty() {
        return (top == null);
    }

    /**
     * Push a new item at the top of the stack
     *
     * @param item
     */
    @Override
    public void push(T item) {

        //create a new node with its pointer(next) to top
        Node<T> newNode = new Node(item, top);    //its next is top??
        top = newNode;                           // top points at new node 

    }

    //add exceptions 
    /**
     *
     * @return the data at the top of the stack
     * @throws EmptyStackException
     */
    @Override
    public T pop() throws EmptyStackException {

        //create a new node, set it to the top so it contains the data at the top of the list???
        Node<T> toPop = top;

        //if the stack is not empty
        //set top to the next item have toPop at the top already so that it skips over toPop
        //set toPop to null to break it from the stack
        //return toPops data
        if (!isEmpty()) {
            top = top.getNext();
            toPop.setNext(null);
            return toPop.getItem();

        } else {
            //throw exception (39:15)
            throw new EmptyStackException("Stack is Empty");
        }
    }

    /**
     * Returns the value at the top of the stack, LIFO
     *
     * @return
     * @throws EmptyStackException
     */
    //add exceptions
    @Override
    public T peek() throws EmptyStackException {
        //if the stack is empty, throw error 
        if (isEmpty()) {
            throw new EmptyStackException("Stack is Empty");
        }
        return top.getItem();

    }

    /**
     * clears the stack by popping all of the entries one at a time
     */
    @Override
    public void clear() {
        try {
            //while the stack is not empty
            while (!isEmpty()) {
                pop();
            }
        } catch (EmptyStackException ex) {
            System.err.println("LinkedStack.isEmpty() has an implementation problem.");
            ex.printStackTrace();
            System.exit(1);

        }
    }

}
