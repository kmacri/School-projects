/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.merrimack.fop2.mavenproject1;

/**
 *
 * @author kmacr
 */
public class PostfixCalculator {

    //create a new LinkedStack call stack
    private LinkedStack<Integer> stack;

    //contructor 
    public PostfixCalculator() {
        stack = new LinkedStack<Integer>();

    }
    /**
     * Splits a strong by the empty space dilimiter, iterate throguh each element
     * of each string and pop it to the stack if its a number or perform the appropriate operator.
     * 
     * @param postfixExpression
     * @return: peeks the top number from the stack
     * @throws EmptyStackException
     * @throws PostfixCalculatorException
     * @throws IllegalArgumentException 
     */

    public int evaluate(String postfixExpression) throws EmptyStackException, PostfixCalculatorException, IllegalArgumentException  {

        //break the string into pieces using " " dilimiter
        String[] splitExpression = postfixExpression.split(" ");

        //iterate through the array
        for (int i = 0; i < splitExpression.length; i++) {
            
            try {
                int number = Integer.parseInt(splitExpression[i]);
                stack.push(number);

            } catch (NumberFormatException ni) {

                if (splitExpression[i].equals("+")) {
                    //pop the previous two values from the stack
                    //perform the operation, and then push the result back onto the stack
                    int a = stack.pop();
                    int b = stack.pop();
                    int result = a + b;
                    stack.push(result);

                } else if (splitExpression[i].equals("-")) {
                    int a = stack.pop();
                    int b = stack.pop();
                    int result = b - a;
                    stack.push(result);

                } else if (splitExpression[i].equals("*")) {
                    int a = stack.pop();
                    int b = stack.pop();
                    int result = a * b;
                    stack.push(result);

                } else if (splitExpression[i].equals("/")) {
                    int a = stack.pop();
                    int b = stack.pop();
                    if (a == 0){
                        throw new IllegalArgumentException("Cant divide by 0");
                    }
                        int result = b / a;
                        stack.push(result);
                    
                    
                    
                    //could create a utility method check if it an integer or not, isaNumner boolean true/false

                } else if (splitExpression[i].equals("%")) {
                    int a = stack.pop();
                    int b = stack.pop();
                    int result = b % a;
                    stack.push(result);

                }
                else {
                    throw new PostfixCalculatorException("There is unknown character");
                }

            }
        }
        int topNumber = stack.peek();

        return topNumber;
    }

}
