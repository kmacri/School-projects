/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package edu.merrimack.fop2.mavenproject1;

/**
 *
 * @author kmacr
 */
public interface StackInterface<T> {
    public boolean isEmpty();
    public void push(T entry);
    public T pop() throws EmptyStackException;
    public T peek() throws EmptyStackException;
    public void clear();
    
}
