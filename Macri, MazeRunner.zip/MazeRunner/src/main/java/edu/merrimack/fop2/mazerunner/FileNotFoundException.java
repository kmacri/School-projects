/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.merrimack.fop2.mazerunner;

/**
 *
 * @author kmacr
 */
public class FileNotFoundException extends Exception{
    public FileNotFoundException (String message) {
        super(message);
    }
    
}
