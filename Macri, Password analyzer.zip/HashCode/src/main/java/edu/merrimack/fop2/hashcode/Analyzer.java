package edu.merrimack.fop2.hashcode;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

/**
 * Super class that contains utility methods for Project 6
 *  
 * @author Ed Grzyb
 */
public abstract class Analyzer {
    
    protected ListInterface<String> lines;   

    public Analyzer(String fileName) {
        try {
            readLinesFromFile(fileName);
        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    public ListInterface<String> getLines() {
        return lines;
    }

    public ListInterface<String> readLinesFromFile(String fileName) throws FileNotFoundException {
        lines = new LinkedList<>();
        // create a File object based on the fileName provided
        File file = new File(fileName);

        Scanner scanner = new Scanner(file); // use the file instead of the keyboard for input
        // go through each line of the file
        int i = 0;
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            lines.insert(i++, line);
        }

        return lines;
    }    
    
    public String applySHA(String originalString) {
        MessageDigest digest;
        byte[] encodedhash = null;
        try {
            digest = MessageDigest.getInstance("SHA-256");
            encodedhash = digest.digest(originalString.getBytes(StandardCharsets.UTF_8));
        } catch (NoSuchAlgorithmException ex) {
            ex.printStackTrace();
        }

        StringBuilder hexString = new StringBuilder(2 * encodedhash.length);
        for (int i = 0; i < encodedhash.length; i++) {
            String hex = Integer.toHexString(0xff & encodedhash[i]);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }    
    
}
