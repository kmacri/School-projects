/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.merrimack.fop2.hashcode;

/**
 * This class will read and parse the document provided and return some
 * statistics.
 *
 * @author kmacr
 */
public class DocumentAnalyzer extends Analyzer {

    //Two dictionaries, one to represent number of words, one for number of letters
    //key is the word (String), value is integer represnets the count
    private DictionaryInterface<String, Integer> words = new LinkedDictionary();

    //key is teh character
    private DictionaryInterface<Character, Integer> letters = new LinkedDictionary();

    //contructor
    public DocumentAnalyzer(String fileName) {
        //calls the constructor of the Analyzer superclass
        super(fileName);

    }

    /**
     * Return an Entry that contains the word that appears most in the file and
     * the count of the number of times it is present.
     *
     * @return
     */
    public Entry<String, Integer> findMostRecurringWord() {

   
        for (int i = 0; i < lines.getLength(); i++) {
            
            String[] wordsArray = lines.getEntry(i).split("\\s+");
            
            //have to get rid of punctuations so they dont count as different words when getting a count
            //for each element in words array:
            for (String word : wordsArray) {
                if (word.length()>1){
                
                //get the last char of the word if it is a punctuation, get rid of it. 
                char punctuation = word.charAt(word.length() - 1);
                if (punctuation == '.' || punctuation == ',' || punctuation == ';' || punctuation == ':'
                        || punctuation == '?' || punctuation == '!') {
                    //get rid of the punction and save the word
                    word = word.substring(0, word.length() - 1);
                }
                //Here we have each word without punction
                //if the value of the word is null aka its count is 0, makes its value (count 1)
                if (words.getValue(word) == null) {
                    words.add(word, 1);
                } //else if it does have a value, add the word and increment its value by 1
                else {
                    words.add(word, words.getValue(word) + 1);
                }
                }
            }

        }
        //use getEntry(key) to retun
        int highestValue = -1;
        String highestKey = "";
        
        //list of string, similar to array 
        ListInterface<String> keysList = words.getKeys();
        
        for (int i = 0; i < keysList.getLength(); i++){
            String key = keysList.getEntry(i);
            //returns integer object non
            //make sure i
            Integer value = words.getValue(key);
            if (value > highestValue){
                highestValue = value;
                highestKey = key;
            }
            
        }
        
        System.out.println(highestKey);
        System.out.println(highestValue);
        //highestEntry.setValue(highestValue);
        Entry highestEntry = new Entry<String, Integer>(highestKey, highestValue);
        return highestEntry;

    }

    //find the greatest value in the key/value pair. Get each entry, get value, keep track of the largest one. 
    //return the entry in the list with the biggest size. 
    //use a temp string, keep updating it

    
    public Entry<String, Integer> findMostRecurringCharacter() {
        //readlineFromFile in analyzer: creates a linked list (lines) and a new file obj with name provided(fileName)
        // for each line in lines 
        for (int i = 0; i < lines.getLength(); i++) {
            //aka each element of the String array below will be a word using white space as a dilimiter 
            String[] stringArray = lines.getEntry(i).split("\\s+");

            //get rid of the punctuation and save the word
            //for each element in stringArray (each string)
            for (String word : stringArray) {
                if (word.length()>1){
                char punctuation = word.charAt(word.length() - 1);
                if (punctuation == '.' || punctuation == ',' || punctuation == ';' || punctuation == ':'
                        || punctuation == '?' || punctuation == '!') {
                    word = word.substring(0, word.length() - 1);
                }

                //Here we have each word without punction in stringArray 
                //need each char
                //for each word in stringArray
                for (int j = 0; j < word.length(); j++) {
                    //for each char 
                    if (letters.getValue(word.charAt(j)) == null) {
                        //add the char
                        letters.add(word.charAt(j), 1);
                    } //else if it does have a value, add the word and increment its value by 1
                    else {
                        letters.add(word.charAt(j), letters.getValue(word.charAt(j)) + 1);
                    }
                }

                }
                
            }
            

    }
            int highestCharValue = -1;
            char highestCharKey = 0;
        
            //list of char, similar to array 
            //Character object 
            ListInterface<Character> newKeysList = letters.getKeys();
        
            for (int i = 0; i < newKeysList.getLength(); i++){
                char charKey = newKeysList.getEntry(i);
                //returns integer object non
                //make sure i
                Integer keyValue = letters.getValue(charKey);
                if (keyValue > highestCharValue){
                    highestCharValue = keyValue;
                    highestCharKey = charKey;
                }

        }
        System.out.println(highestCharKey);
        System.out.println(highestCharValue);
            
        Entry highestEntry = new Entry<Character, Integer>(highestCharKey, highestCharValue);
        return highestEntry;
        
        
        
    }
    
    /**
     * retuns the number of unique words in the file
     * @return 
     */
    public int getUniqueWordCount(){
        //get the number of keys in words (linkedDictionary)
        int numWords = words.getSize();
        
        return numWords;
    }
    
    /**
     * Gets the total number of words
     * Get each keys value and sum
     * @return 
     */
    public int getTotalWordCount(){
        int count = 0;
        
        //getKeys: returns a LinkedList of keys
        ListInterface<String> keys = words.getKeys();
        //returns a list of all the keys
        for (int i = 0; i < keys.getLength(); i++){
            String entryKey = keys.getEntry(i);
            
            //returns the value of the key
            Integer keyValue = words.getValue(entryKey);
            count = count + keyValue;

        }
        return count;
    }
    
    public int getUniqueLetterCount(){
        int numCharacters = letters.getSize();
        return numCharacters;
    }
    
    public int getTotalLetterCount(){
        int count = 0;
        //getKeys returns a LinkedList of keys
        ListInterface<Character> charKeys = letters.getKeys();
        
        for (int i = 0; i < charKeys.getLength(); i++){
            char charEntry = charKeys.getEntry(i);
            
            //retuns value of the key
            Integer charValue = letters.getValue(charEntry);
            count = count + charValue;
        }
        return count;
    }

}


