/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package edu.merrimack.fop2.hashcode;

/**
 *
 * @author kmacr
 */
public class HashCode {

    public static void main(String[] args) {

        //call PassWordAnalyzer constructor 
        PasswordAnalyzer passwordAnalyzer = new PasswordAnalyzer("passwords.csv");

        //returns a LinkedDictionary<String, String>
        DictionaryInterface<String, String> userAccounts = passwordAnalyzer.getUserAccounts();

        //list of all the keys 
        ListInterface<String> keys = userAccounts.getKeys();

        String guess = "12345678";
        String firstGuess = passwordAnalyzer.hashPassword(guess);
        
        //Common 8 letter passwords according to google. 
        String[] guesses = new String[]{"12345678", "password", "iloveyou", "sunshine", "football", "princess", "superman"};

        for (int j = 0; j < guesses.length; j++) {
            //changes all the password to hashed passwords
            //guesses[j] = ;
            
        }
        
        //System.out.println(guesses[0]);
        //System.out.println(guesses[5]);

        for (int i = 0; i < keys.getLength(); i++) {
            for (int k = 0; k < guesses.length; k++) {

                //get all the userNames
                String entryKey = keys.getEntry(i);

                //gets all the passwords
                String password = userAccounts.getValue(entryKey);

                //System.out.println(password);
                //System.out.println(guesses[k]);
                //check each password against each guess. 


                    if (password.equals(passwordAnalyzer.hashPassword(guesses[k]))) {

                        //this gives the username of the password
                        System.out.println(keys.getEntry(i) + "Password is: " + guesses[k]);
                    }

            }

        }

    }
}
