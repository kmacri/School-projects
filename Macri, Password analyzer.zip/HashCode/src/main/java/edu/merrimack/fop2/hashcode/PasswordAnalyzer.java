/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.merrimack.fop2.hashcode;

import java.util.Random;

/**
 *
 * @author kmacr
 */
public class PasswordAnalyzer extends Analyzer {

    private DictionaryInterface<String, String> userAccounts = new LinkedDictionary();

    public PasswordAnalyzer(String fileName) {

        //call the constructor of the Analyzer super class
        super(fileName);

        //then you should parse the CSV file and store the username/password combinations 
        //in the userAccounts dictionary 
        //store values in dict, the key is the username and the value is the hashed password
        //each element in lines is a line of the file, username, password
        for (int i = 0; i < lines.getLength(); i++) {
            //print on its own line username, password
            //System.out.println(lines.getEntry(i));

            //
            String[] userNamesArray = lines.getEntry(i).split(",");

            //each element in userNamesArray is username then password
            //this is all the usernames
            for (int j = 0; j < userNamesArray.length; j = j + 2) {
                //System.out.println(userNamesArray[j]);
                String userName = userNamesArray[j];
                String password = userNamesArray[j + 1];
                //System.out.println(userName);

                userAccounts.add(userName, password);
            }

        }

    }

    public String hashPassword(String password) {

        String hashedPassword = applySHA(password);

        return hashedPassword;

    }

    //Inside of the analyzePasswords method, you will call out to any other methods you write to 
    //attempt to decode the passwords
    //method, you will call out to any other methods you write to attempt to decode the passwords.  
    //Analyze passwords should then print out any passwords you guess and the related username.  
    public void analyzePasswords() {

        DictionaryInterface<String, String> userAccounts = getUserAccounts();

        //list of all the keys 
        ListInterface<String> keys = userAccounts.getKeys();

        //Method 1 Common 8 letter passwords according to google. 
        String[] guesses = new String[]{"12345678", "password", "iloveyou", "sunshine", "football", "princess", "superman"};

        for (int i = 0; i < keys.getLength(); i++) {
            for (int k = 0; k < guesses.length; k++) {

                //get all the userNames
                String entryKey = keys.getEntry(i);

                //gets all the passwords
                String password = userAccounts.getValue(entryKey);

                if (password.equals(hashPassword(guesses[k]))) {

                    //this gives the username of the password
                    System.out.println(keys.getEntry(i) + "Password is: " + guesses[k]);
                }

            }
        }
        
        //method 2 username as password
        for (int x = 0; x < keys.getLength(); x++) {
            //for (int a = 0; a < keys.getLength(); a++){
            
                //get all userName to compare  
                String userNames = keys.getEntry(x);
                
                //get the inner loop username 
                //String currentUser = keys.getEntry(a);
            
                //get all the passwords to the username 
                String passwords = userAccounts.getValue(userNames);
                
                //System.out.println(hashPassword(userNames) + " " + passwords);
                
                //if the users username and password are the same thing
                if (hashPassword(userNames).equals(passwords)){
                    
                    System.out.println(keys.getEntry(x) + "Password is: " + passwords);
                    
            }
            
            
        }      

            //method 3 all 8 digit numbers:
            for (int g = 0; g < keys.getLength(); g++) {
                for (int f = 10000000; f <= 99999999; f++) {

                    int numGuess = f;
                    String numGuessAsString = String.valueOf(f);
                    //System.out.println(numGuessAsString);

                    //get all the userNames
                    String userName = keys.getEntry(g);

                    //get all passwords
                    String password = userAccounts.getValue(userName);
                    
                    if ( password.equals(hashPassword(numGuessAsString))){
                    //if ( password == hashPassword(f)){   
                        System.out.println(keys.getEntry(g) + "Password is: " + numGuessAsString);
                    }

                }

            }

        }

    



public DictionaryInterface<String, String> getUserAccounts(){
        
        
        
        return userAccounts;
        
    }
    
    
    
    
    
}
