package edu.merrimack.fop2.hashcode;
//import edu.merrimack.fop2.adt.list.LinkedList;
//import edu.merrimack.fop2.adt.list.ListInterface;
//import edu.merrimack.fop2.adt.tree.BinarySearchTree;
//import edu.merrimack.fop2.adt.tree.BinaryNode;


/**
 * An implementation of a dictionary using a tree.
 *
 */
public class TreeDictionary<K extends Comparable<? super K>, V> implements DictionaryInterface<K, V> {

    private BinarySearchTree<Entry<K, V>> tree;

    /**
     * Constructs a new tree dictionary.
     */
    public TreeDictionary() {
        tree = new BinarySearchTree<>();
    }

    /**
     * Adds a new entry with key {@code key} and value {@code val}.
     *
     * @param key the key associated with the entry.
     * @param val the value associated with the entry.
     * @return null if a new entry was added or the entry that was replaced.
     */
    @Override    
    public V add(K key, V val) {
        Entry<K, V> entry = tree.add(new Entry<>(key, val));

        if (entry == null) {
            return null;
        }
        return entry.getValue();
    }

    /**
     * Removes the entry with key {@code key} from the dictionary.
     *
     * @param key the key associated with the entry to remove.
     * @return the value associated with the key or null.
     */
    @Override    
    public V remove(K key) {
        return getValue(key);
    }

    /**
     * Gets the entry with key {@code key} from the dictionary.
     *
     * @param key the key associated with the entry to retrieve
     * @return the value associated with the key or null.
     */
    @Override    
    public V getValue(K key) {
        Entry<K, V> entry = tree.getEntry(new Entry<>(key, null));

        if (entry == null) {
            return null;
        } else {
            return entry.getValue();
        }
    }

    /**
     * Determines if the dictionary contains an entry with key {@code key}.
     *
     * @param key the key associated with the entry to find.
     * @return true if the key was found in the dictionary; otherwise, false.
     */
    /**
     * Gets a list of all keys in the dictionary.
     *
     * @return a list of keys in the table.
     */
    @Override    
    public boolean contains(K key) {
        return tree.contains(new Entry<>(key, null));
    }

    /**
     * Determines if the dictionary is empty.
     *
     * @return true if the dictionary is empty; otherwise, false.
     */
    @Override    
    public boolean isEmpty() {
        return tree.isEmpty();
    }

    /**
     * Gets the size of the dictionary.
     *
     * @return the number of entries currently in the dictionary.
     */
    @Override
    public int getSize() {
        return tree.getNumberOfNodes();
    }

    /**
     * Removes all entries from the dictionary.
     */
    @Override
    public void clear() {
        tree.clear();
    }
    
    @Override
    public ListInterface<K> getKeys() {
        ListInterface<K> keys = new LinkedList<>();

        BinaryNode<Entry<K,V>> rootNode = tree.getRootNode();
        keys.insert(0, rootNode.getItem().getKey());
        
        /**
         * NOT IMPLEMENTED
         * 
         * traverse tree to get rest of keys
         * 
         * this can be in any traversal order 
         * (pre-order, inorder, post-order)
         */
        
        return keys;
    }       

}
