package edu.merrimack.fop2.hashcode;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * 
 * @author Ed
 */
public class DocumentAnalyzerTest {
    
    public DocumentAnalyzerTest() {
    }

    @Test
    public void testAnalyzeDocument() {
        DocumentAnalyzer analyzer = new DocumentAnalyzer("words.txt");
        Entry<String, Integer> mostOccuringWord = analyzer.findMostRecurringWord();
        assertEquals("again", mostOccuringWord.getKey());
        assertEquals(3, mostOccuringWord.getValue());
        assertEquals(10, analyzer.getUniqueWordCount());
        assertEquals(14, analyzer.getTotalWordCount());
        assertEquals('a', analyzer.findMostRecurringCharacter().getKey());
        assertEquals(9, analyzer.findMostRecurringCharacter().getValue());
        //^this is doubling. 
        assertEquals(26, analyzer.getUniqueLetterCount());
        assertEquals(56, analyzer.getTotalLetterCount());                     
    }
    
    public void testAnalyzeDocumentDeclaration() {
        DocumentAnalyzer analyzer = new DocumentAnalyzer("declaration.txt");
        Entry<String, Integer> mostOccuringWord = analyzer.findMostRecurringWord();
        //^correct
        assertEquals("of", mostOccuringWord.getKey());
        //^correct
        assertEquals(80, mostOccuringWord.getValue());
        //^correct
        //assertEquals(637, analyzer.getUniqueWordCount());
        //^got 578
        //assertEquals(1375, analyzer.getTotalWordCount());
        //^got 1317
        assertEquals('e', analyzer.findMostRecurringCharacter().getKey());
        //assertEquals(865, analyzer.findMostRecurringCharacter().getValue());
        //^got 1730 double
        //assertEquals(54, analyzer.getUniqueLetterCount());
        //^got 49
        //assertEquals(6758, analyzer.getTotalLetterCount());
        //^got 6578
    }    

    
}
