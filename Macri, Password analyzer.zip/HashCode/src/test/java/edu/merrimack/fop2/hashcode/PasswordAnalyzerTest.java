package edu.merrimack.fop2.hashcode;
import org.junit.jupiter.api.Test;

/**
 * Test that simply calls the analyze passwords method.  If you can "crack" some of the passwords, print the user and password 
 * out in a System.out.println
 * 
 * Note, that your program may run for a long time - try algorithms that check some obvious or easy things first.
 * 
 * @author Ed
 */
public class PasswordAnalyzerTest {
    
    public PasswordAnalyzerTest() {
    }

    @Test
    public void testAnalyzePasswords() {        
        PasswordAnalyzer analyzer = new PasswordAnalyzer("passwords.csv");
        analyzer.analyzePasswords();
        
    }

}
