/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package edu.merrimack.fop2.tictactoe;

/**
 *
 * @author kmacr
 */
public enum BoardStatus {
    UNFINISHED,
    X_WINS,
    O_WINS,
    DRAW;
    
    
}
