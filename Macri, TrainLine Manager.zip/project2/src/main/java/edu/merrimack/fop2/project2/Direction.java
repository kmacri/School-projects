/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package edu.merrimack.fop2.project2;

/**
 *
 * @author kmacr
 */
public enum Direction {
    INBOUND("Inbound"),
    OUTBOUND("Outbound");
    
    private final String displayName;

    
    Direction(String displayName){
        this.displayName = displayName;

    }
    
    
    public String getDisplayName() {
        return displayName;
    }

    //****Do I need to create a getInbound and getOutbound
    
    
}
 //Call it with Direction.INBOUND.getDisplayName()
//Call it with Direction.INBOUND.getInbound()