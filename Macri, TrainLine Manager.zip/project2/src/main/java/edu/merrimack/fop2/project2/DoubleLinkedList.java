
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.merrimack.fop2.project2;
//import edu.merrimack.fop2.adt.list.ListInterface;//*****What is going on here????

/**
 * Start with the LinkedList.java class and then modify as specified in the
 * assignment
 */
public class DoubleLinkedList<T> implements ListInterface<T> {

    private DoubleNode<T> head;    // The reference to the head of the list.
    private int itemCount;   // The number of items in the list. The number of nodes in doubly linked list

    /**
     * Default constructor creates an empty list.
     */
    public DoubleLinkedList() {
        this.head = null;
        this.itemCount = 0;
    }

    /**
     * Returns true if the list is empty (itemCount = 0) and false otherwise.
     *
     * @return true if the list is empty; otherwise, false.
     */
    @Override
    public boolean isEmpty() {
        return (itemCount == 0);
    }

    /**
     * Returns the number of elements in the list (itemCount).
     *
     * @return a number >= 0.
     */
    @Override
    public int getLength() {
        return this.itemCount;
    }

    /**
     * This method inserts a new piece of data into the list at index
     * {@code index}.
     *
     * @param index the index in the list to insert the element at.
     * @param entry the data to insert into the list.
     * @return true if the insertion was successful and false otherwise.
     */
    @Override
    //insert node at head
    // 1. allocate a new node
    // 2. Point next (setNext) of newNode to head of list
    // 3. Point head (setHead) of list at new node which is new head of list 

    //
    public boolean insert(int index, T entry) {
        DoubleNode<T> newNode = null;
        DoubleNode<T> previous = null;

        // Check for a valid insert.
        if (index < 0 || index > itemCount) {
            return false;
        }
        // Allocate a new node to insert.
        newNode = new DoubleNode<>(entry); //entry is the data of type T
        if (index == 0) { // Insert at front setting head to newNode        
            newNode.setNext(head);  //placing newNode before head, new node pointer is at head
            head = newNode;         // now set new node as the head. 
            //make sure head isnt null, set previous to head to new node. previous to head needs to point to new Node, make sure head isnt null

            //if we are not placing at the beginning but at an index 
            //Allocate newNode 
            //Locate previous node use getNodeat(index-1)
            //point newNode (setNext) to previous.getNext()
            //Assign previous.getNext() to newNode
        } else {
            previous = getNodeAt(index - 1);   // Get the predecessor node and set it to previous. 
            newNode.setNext(previous.getNext()); //
            previous.setNext(newNode);
            //give new node a pointer to the previous node
            newNode.setPrevious(previous); //*****Is this correct? we are setting the previous node to the newNode to index-1???

        }
        itemCount++;
        return true;
    }

    /**
     * This method removes an element from the list, reducing the size of the
     * list.
     *
     * @param index of the element to remove.
     * @return true if the removal was successful; otherwise, false.
     */
    @Override
    //1. Locate previous node with getNodeat(index-1) call it previous
    //2. Point previous (.getNext) to the next node which is the node we want to delete call it toDelete
    //3. set the previous node pointer to the toDelete.getNext() node thus bypassing the toDelete node 
    //4. set the getNext of toDelete to null
    //5. optionally set toDelete to null

    public boolean remove(int index) {
        DoubleNode<T> previous = null;
        DoubleNode<T> toDelete = null;
        // Nothing to remove.
        if (index < 0 || index >= itemCount) {
            return false;
        }
        if (index == 0) {
            toDelete = head;
            head = head.getNext();
        } else { // Find the predecessor and link things up.        
            previous = getNodeAt(index - 1);
            toDelete = previous.getNext();
            previous.setNext(toDelete.getNext());
            // Unlink the node.
            toDelete.setNext(null);
            toDelete.setPrevious(null);
            //set nex to the toDelete getPrevious to two previous ago
            //What am i calling setPrevious on? previous?
        }
        itemCount--;    // We have one less item.
        return true;
    }
    
   

    /**
     * This method should return the index of the item (the key) passed in if it
     * is in the list or -1 if the key is not found The ‘find’ method must make
     * use of the object’s equals method (inherited/overridden from the Object
     * class) to compare the key passed into the value(s) in the list to
     * determine if it is present.
     */
    
     /**
     * This method takes T as a parameter iterates through the linked list and retuns the index of the 
     * searched data
     * {@code index}.
     *
     * @param  key is the data we are looking for
     * @return the index of the data we are looking for or -1 if data is not found. 
     */

    public int find(T key) {
        DoubleNode<T> visitor = head;      //Start at the beginning of the linkedList
        int searchedIndex = 0;
        while (visitor != null) {    //while visitor is not null, while not at the end of the list
            if (visitor.getItem().equals(key)) {   
                return searchedIndex;
            }
            searchedIndex++;     //increment searched index
            visitor = visitor.getNext(); //if it did not match incement the index and get the next item 
        }
        if (visitor == null){
                return -1;
            }
        return searchedIndex;

    }

    /**
     * This method clears the list by deleting all of the nodes in the chain.
     */
    @Override
    public void clear() {
        while (!isEmpty()) {
            remove(0);
        }
    }

    /**
     * Determines if {@code entry} is contained in the list.
     *
     * @param entry the entry to search for.
     * @return true if the entry is in the list; otherwise, false.
     */
    @Override
    public boolean contains(T entry) {
        DoubleNode<T> visitor = head;
        // Walk the chain. If the entry is found, return true.
        for (visitor = head; visitor != null; visitor = visitor.getNext()) {
            if (visitor.getItem().equals(entry)) {
                return true;
            }
        }
        // We've visited the entire chain and did not find the entry; return false.
        return false;
    }

    /**
     * This method gets the entry at the location if the location is valid.
     *
     * @param index a index in the list.
     * @return The data stored at the index in the list.
     * @throws IndexOutOfBoundsException if the index is not valid.
     */
    @Override
    public T getEntry(int index) throws IndexOutOfBoundsException {
        if (index < 0 || index >= itemCount) {
            throw new IndexOutOfBoundsException("Invalid index.");
        }
        return getNodeAt(index).getItem();
    }

    /**
     * This method replaces the item at entry if valid and returns the old
     * entry.
     *
     * @param index the index in the list to change.
     * @param entry the new data to replace in the list.
     * @return the data that was replaced.
     * @throws IndexOutOfBoundsException if the position is not valid.
     */
    @Override
    public T replace(int index, T entry) throws IndexOutOfBoundsException {
        DoubleNode<T> replaceNode = null;
        T old;
        if (index < 0 || index >= itemCount) {
            throw new IndexOutOfBoundsException("Invalid position.");
        }
        replaceNode = getNodeAt(index);
        old = replaceNode.getItem();
        replaceNode.setItem(entry);
        return old;
    }

    /**
     * Returns the array form of the list data.
     *
     * @return an array of list data ordered the same as the list.
     */
    @Override
    public Object[] toArray() {
        Object[] array = (T[]) new Object[itemCount];
        DoubleNode<T> visitor;   // Reference used to visit the list.
        int idx = 0;      // Index into the array of elements.
        for (visitor = head; visitor != null; visitor = visitor.getNext()) {
            array[idx++] = visitor.getItem();
        }
        return array;
    }

    /**
     * Returns a string representation of the list.
     *
     * @return A string representation of the list.
     */
    @Override
    public String toString() {
        String ret = "";
        DoubleNode<T> visitor = head;
        int index = 0;
        // Check to see if the list is empty.
        if (itemCount == 0) {
            ret = "Empty List.";
        }
        // Print out all of the elements of the list.
        while (visitor != null) {
            ret += "[" + index + "]: " + visitor.getItem() + "\n";
            index++;
            visitor = visitor.getNext();
        }
        return ret;
    }

    /**
     * This method returns the node at location index in the chain.
     *
     * @param index a valid index in the list.
     * @return the Node at index {@code index} in the chain.
     */

    //This is the visitor pattern, goes through 1 by 1 until it finds the specific position you want to be at
    //and returns it. 
    private DoubleNode<T> getNodeAt(int index) {
        DoubleNode<T> visitor = null;      //creates a node called visitor 
        assert (index >= 0 && index < itemCount);
        visitor = head;   // Point at the start of the chain.
        for (int i = 0; i < index; i++) { // 
            visitor = visitor.getNext(); //continues to get the next node until we reach the index we were looking for 
        }
        return visitor;
    }
}
