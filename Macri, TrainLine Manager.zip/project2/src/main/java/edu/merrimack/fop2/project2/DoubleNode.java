/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.merrimack.fop2.project2;
/**
 * Start with the Node.java class and then modify as specified
 * in the assignment
 * 
 */
public class DoubleNode<T> {
    private T item;          // The nodes data. The item that we are storing
    private DoubleNode<T> next;    // Pointer to the next node
    private DoubleNode<T> previous; //The pointer to the previous item in the list
    /**
     * The default constructor. It sets the next reference to null.
     */
    public DoubleNode() {
        this.next = null;
    }
    /**
     * This is the overloaded constructor that sets the item to itm and the next
     * reference to null.
     *
     * @param itm the item stored in the node. //itm is the data
     */
    public DoubleNode(T itm) {
        this.item = itm;
        this.next = null;
        this.previous = null; // added this???
    }
    /**
     * This is the overloaded constructor that sets the item to itm and the next
     * reference to nxt.
     *
     * @param item the item to be stored in the node.
     * @param next the reference to the next node in the chain.
     * @param previous the reference to the previous node in the chain.
     */
    public DoubleNode(T item, DoubleNode<T> next, DoubleNode<T> previous) {
        this.item = item;
        this.next = next;
        this.previous = previous;
    }
    /**
     * Set the item field of the node to item.
     *
     * @param item the item to store in the node.
     */
    public void setItem(T item) {
        this.item = item;
    }
    /**
     * Get the value stored in the item field of the node.
     *
     * @return the item stored in the node.
     */
    public T getItem() {
        return item;
    }
    /**
     * Set the value of the next reference.
     *
     * @param next the reference to the next node in the chain.
     */
    public void setNext(DoubleNode<T> next) {
        this.next = next;
    }
    /**
     * Return the reference to the next node in the chain.
     *
     * @return the reference to the next node in the chain.
     */
    public DoubleNode<T> getNext() {
        return this.next;
    }
    
        /**
     * Set the value of the next reference.
     *
     * @param previous the reference to the prior node in the chain.
     */
    public void setPrevious(DoubleNode<T> previous) {
        this.next = previous;
    }
    /**
     * Return the reference to the previous node in the chain.
     *
     * @return the reference to the previous node in the chain.
     */
    public DoubleNode<T> getPrevious() {
        return this.previous;
    }
}
