/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.merrimack.fop2.project2;
/**
 * Starting point for Train - add to this as specified in assignment
 *
 */
public class Train {
    private int number;
    private Direction direction;
    
    // add other attributes, getters/setters and constructor
    
    //Constructor 
    public Train(int number, Direction direction){
        this.number = number;
        this.direction = direction;
    }
    
    //getter and setters
    
    public void setNumber(int number){
        this.number = number;
    }
    
    public void setDirection(Direction direction){
        this.direction = direction;
    }
    
    public int getNumber(){
        return number;
    }
    
    public Direction getDirection(){
        return direction;
    }
    
    
    
    
    @Override
    public String toString() {
        String trainString = Integer.toString(number);
        while (trainString.length() < 10) {
            if (trainString.length() % 2 == 0) {
                trainString = " " + trainString;
            } else {
                trainString += " ";
            }
        }
        return trainString;
    }        
}
