/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.merrimack.fop2.project2;

/**
 * Starting point for TrainLine - add to this as specified in assignment
 *
 * Note that this will not compile until you implement the getLength() and
 * getEntry() methods in DoubleLinkedList
 *
 */
public class TrainLine {

    private DoubleLinkedList<TrainStation> trainStations = new DoubleLinkedList<>();   //Linked list of trainStations 

    public TrainLine() {

        TrainStation packards = new TrainStation("Packards");
        TrainStation harvard = new TrainStation("Harvard");
        TrainStation griggs = new TrainStation("Griggs");
        TrainStation allston = new TrainStation("Allston");
        TrainStation wash = new TrainStation("Wash");

        //Create trains inbound and outbound, fill their constructors 
        //then set them to side inbound or outbound
        Train inbound = new Train(123, Direction.INBOUND);
        packards.setInbound(inbound);

        Train outbound = new Train(456, Direction.OUTBOUND);
        wash.setOutbound(outbound);

        //inserting the trainStation on our DoubleLinked list
        trainStations.insert(0, packards);
        trainStations.insert(1, harvard);
        trainStations.insert(2, griggs);
        trainStations.insert(3, allston);
        trainStations.insert(4, wash);


    }
    
    /**
     * Adds a train station to the linked list. 
     * @param stationName
     * @param index
     * @throws TrainStationNotAddedException 
     */

    public void addTrainStation (String stationName, int index) throws TrainStationNotAddedException {
        
        for (int i = 0; i < trainStations.getLength(); i++) {
            if (index > trainStations.getLength() || stationName.equals(trainStations.getEntry(i).getName())){
                throw new TrainStationNotAddedException("Index is out of bound or name already exists");
            }
        }
        
        TrainStation newStation = new TrainStation(stationName);
        trainStations.insert(index, newStation);
    }
    
    /**
     * Removes a train station from the linked list
     * @param stationName
     * @throws TrainStationNotRemovedException 
     */

    public void removeTrainStation(String stationName)throws TrainStationNotRemovedException {
        //if the train station cannot be removed because the index is out of range or the train isn’t found
        TrainStation newStation = new TrainStation(stationName);
        for (int i = 0; i < trainStations.getLength(); i++) {
            if (i > trainStations.getLength() || trainStations.find(newStation) == -1){
                throw new TrainStationNotRemovedException("Index is out of range or train isnt found");
            }
        }
         //creates a train station object iwth name passed in as string
        if (trainStations.find(newStation) != -1) {                //if the station is in the list, find retuns int
            trainStations.remove(trainStations.find(newStation)); //remove the station 
        } else {
            System.out.println("Train station could not be found");
        }
    }
    
    /**
     * Adds a train on the inbound side. 
     * @param name
     * @param stationName 
     */

    public void addInboundTrain(int name, String stationName) {
        //new train station created from string user input
        TrainStation newStation = new TrainStation(stationName);
        
        if (trainStations.find(newStation) == -1){
            System.out.println("Station cannot be found");
        }
        
        
        Train newInboundTrain = new Train(name, Direction.INBOUND);

        
        //iterates through the linked list, checking if names are the same. 
        for (int i = 0; i < trainStations.getLength(); i++) {
            if (newStation.getName().equals(trainStations.getEntry(i).getName())) {
                trainStations.getEntry(i).setInbound(newInboundTrain);
            }
        }
    }

    /**
     * Adds a train on the outbound side
     * @param name
     * @param stationName
     */

    public void addOutboundTrain(int name, String stationName) {
        
        TrainStation newStation = new TrainStation(stationName);
        if (trainStations.find(newStation) == -1){
            System.out.println("Station cannot be found");
        }
        

        //create train
        Train newOutboundTrain = new Train(name, Direction.OUTBOUND);

        //new train station created from string user input
        
        //iterates through the linked list, checking if names are the same. 
        for (int i = 0; i < trainStations.getLength(); i++) {
            if (newStation.getName().equals(trainStations.getEntry(i).getName())) {
                trainStations.getEntry(i).setOutbound(newOutboundTrain);
            }
        }
    }
    
    
    /**
     * Takes a train station as a parameter and retuns the next staion in the line
     * @param trainStation
     * @return TrainStation
     * @throws TrainStationNotFoundException 
     */


    public TrainStation getNextTrainStation(TrainStation trainStation) throws TrainStationNotFoundException {
        
        if (trainStations.find(trainStation) == -1) {
            throw new TrainStationNotFoundException("Train station not Found");
        }
        
        //if (trainStations.find(trainStation) != -1) { //dont need this with the exception
        
            int trainStationInt = trainStations.find(trainStation); //find the elemnt of the passed in trainStation
            TrainStation nextTrainStation = trainStations.getEntry(trainStationInt + 1); //returns the next trainStation follow the one that was passed in

            return nextTrainStation;

        
    }
    
    /**
     * Takes a train station as a parameter and retuns the previous staion in the line
     * @param trainStation
     * @return TrainStation
     * @throws TrainStationNotFoundException 
     */

    public TrainStation getPreviousTrainStation(TrainStation trainStation) throws TrainStationNotFoundException {
        
        if (trainStations.find(trainStation) == -1) {
            throw new TrainStationNotFoundException("Train station not Found");
        }
        
        //if (trainStations.find(trainStation) != -1) {
            int trainStationInt = trainStations.find(trainStation); //find the elemnt of the passed in trainStation
            TrainStation previousTrainStation = trainStations.getEntry(trainStationInt - 1); //returns the previous trainStation follow the one that was passed in

            return previousTrainStation;
        //return null;
    }
    
    
    
    /**
     * Move both trains their respective directions 
     * return void
     * parameters: none
     */
    
    //inbound is a train at griggs moving left
    //outbound is a train is a train at packards moving right
    //if i is greater than the length of the line, set the inbound train to null
    public void moveTrains() {
        for (int i = trainStations.getLength() - 1; i >= 0; i--) {
            if (i == 0) {

                trainStations.getEntry(i).setInbound(null);  //setting it to null if it goes past index 
            } 
            
            //getEntry returns T or trainStation
            //if the current station outbound value is not null
            //place inbound at the prevous index
            //and make the current index null
            
            else {
                trainStations.getEntry(i).setInbound(trainStations.getEntry(i - 1).getInbound());
                //trainStations.getEntry(i).setInbound(null);
            }
        }

        for (int i = 0; i < trainStations.getLength(); i++) {
            if (i == trainStations.getLength() - 1) {
                trainStations.getEntry(i).setOutbound(null);
            } else {
                trainStations.getEntry(i).setOutbound(trainStations.getEntry(i + 1).getOutbound());
                //trainStations.getEntry(i).setOutbound(null);
            }
        }
    }
    /**
     * 
     * Takes a string and searches the Trainline for the station, returns the station if found. 
     * @param stationName
     * @return TrainStation
     * @throws TrainStationNotFoundException
     */

    public TrainStation findTrainStationByName(String stationName) throws TrainStationNotFoundException {
        TrainStation newStation = new TrainStation(stationName);
        
        if (trainStations.find(newStation) == -1) {
            throw new TrainStationNotFoundException("Train station not Found");
        }
        
        
        //search for trainStation by name 
        
        //Do i need the -1 after getLength
        for (int i = 0; i < trainStations.getLength(); i++) {
            if (newStation.getName().equals(trainStations.getEntry(i).getName())) {
                return newStation;

            }
        }

       return null;
    }
    
    @Override
    public String toString() {
        String trainLineString = "+----------+";
        for (int i = 0; i < trainStations.getLength(); i++) {
            trainLineString += "----------+";
        }
        trainLineString += "\n|  STATION:|";
        for (int i = 0; i < trainStations.getLength(); i++) {
            trainLineString += trainStations.getEntry(i);
            trainLineString += "|";
        }
        trainLineString += "\n+----------+";
        for (int i = 0; i < trainStations.getLength(); i++) {
            trainLineString += "----------+";
        }

        // INBOUND
        trainLineString += "\n|  INBOUND:|";
        for (int i = 0; i < trainStations.getLength(); i++) {
            Train inbound = trainStations.getEntry(i).getInbound();
            String stationString = "  EMPTY   ";
            if (inbound != null) {
                stationString = "" + inbound.toString();
            }
            trainLineString += stationString + "|";
        }

        trainLineString += "\n+----------+";
        for (int i = 0; i < trainStations.getLength(); i++) {
            trainLineString += "----------+";
        }
        // OUTBOUND
        trainLineString += "\n| OUTBOUND:|";
        for (int i = 0; i < trainStations.getLength(); i++) {
            Train outbound = trainStations.getEntry(i).getOutbound();
            String stationString = "  EMPTY   ";
            if (outbound != null) {
                stationString = "" + outbound.toString();
            }
            trainLineString += stationString + "|";
        }

        trainLineString += "\n+----------+";
        for (int i = 0; i < trainStations.getLength(); i++) {
            trainLineString += "----------+";
        }

        return trainLineString;
    }
}
