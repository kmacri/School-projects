/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package edu.merrimack.fop2.project2;
import java.util.Scanner;
/**
 * Kyle Macri 
 * Project 2 
 * Foundations 2
 * Starting code for your main program
 */
public class TrainLineManager {
    public static void main(String args[]) {
        TrainLine line = new TrainLine();
        Scanner scanner = new Scanner(System.in);
        int choice = 0;
        do {
            System.out.println("What do you want to do?");
            System.out.println("1. Show the trains and stations.");
            System.out.println("2. Move trains.");
            System.out.println("3. Add an inbound train.");
            System.out.println("4. Add an outbound train.");
            System.out.println("5. Add a station.");
            System.out.println("6. Remove a station.");
            System.out.println("7. End Program");
            choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    //Show Trains
                    System.out.println(line);
                    break;
                case 2:
                    // move trains
                    line.moveTrains();
                    System.out.println("Trains have been moved by 1 station");
                    System.out.println(line);
                    break;
                case 3:
                    // add inbound train
                    Scanner inboundTrainStationScanner = new Scanner(System.in);
                    System.out.println("Which station do you want to place the train:  ");
                    String trainStationInt = inboundTrainStationScanner.nextLine();
                    System.out.println("Enter name of the new train as integer: ");
                    int trainNameAsInt = inboundTrainStationScanner.nextInt();
                    
                    line.addInboundTrain(trainNameAsInt,trainStationInt );
                    System.out.println(line);
                    break;
                case 4:
                    // add your code here
                    Scanner OutboundTrainStationScanner = new Scanner(System.in);
                    System.out.println("Which station do you want to place the train:  ");
                    String outTrainStationString = OutboundTrainStationScanner.nextLine();
                    System.out.println("Enter name of the new train as integer: ");
                    int OutTrainNameAsInt = OutboundTrainStationScanner.nextInt();
                    
                   // int trainInt = line.addOutboundTrain(OutTrainNameAsInt, outTrainStationString);
                    //System.out.println(trainInt);
                    
                    line.addOutboundTrain(OutTrainNameAsInt,outTrainStationString );
                    System.out.println(line);
                    break;
                case 5:
                    // Add station
                    
                    Scanner newStationScanner = new Scanner(System.in);
                    System.out.println("Enter name of the new station: ");
                    String addedStationName = newStationScanner.nextLine();
                    System.out.println("Enter index of the new station: ");
                    int stationIndex = scanner.nextInt();
                    try {
                        line.addTrainStation(addedStationName, stationIndex);
                    }catch(TrainStationNotAddedException ae){
                        System.out.println("oops" + ae.getMessage());
                    }
                    System.out.println("Station added");
                    System.out.println(line);
                    
                    break;
                case 6:
                    // add your code here
                    Scanner secondStationScanner = new Scanner(System.in);
                    System.out.println("Enter name of the station you want to remove: ");
                    String removedStationName = secondStationScanner.nextLine();
                    
                    try {
                       line.removeTrainStation(removedStationName); 
                    }catch(TrainStationNotRemovedException nr){
                        System.out.println("oops" + nr.getMessage());
                    }
                    System.out.println("Station removed");
                    System.out.println(line);
                    break;
                case 7:
                    break;                    
                default:
                    System.out.println("Invalid choice");
            }
        } while (choice != 7);
    }
}