/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.merrimack.fop2.project2;

import java.util.Objects;

/**
 * Starting point for TrainStation - add to this as specified in assignment
 * 
 * 
 */


//TrainStation is our T, or our data
public class TrainStation {
    private String name;
    private Train inbound;  
    private Train outbound;
    
    // add other getters/setters/constructor 
    
    //contructor
    public TrainStation(String name) {
        this.name = name;
        this.inbound = null;
        this.outbound = null;
    
    }
    
    public void setName(String name){
        this.name = name;
    }
    
    public String getName() {
        return name;
    }
    
     public void setInbound(Train inbound){
        this.inbound = inbound;
    }
     
     public Train getInbound(){
        return inbound;
    }
     
     public void setOutbound(Train outbound){
        this.outbound = outbound;
    }
     
     public Train getOutbound(){
        return outbound;
    }
    
    
    @Override
    public String toString() {
        String stationString = "";
        if (name != null) {
            stationString = name;
            while (stationString.length() < 10) {
                if (stationString.length() % 2 == 0) {
                    stationString = " " + stationString;
                } else {
                    stationString += " ";
                }
            }
        }
        return stationString;
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj) {  //if same object have to be equals 
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TrainStation other = (TrainStation) obj;  //casting, has to be a trainStation object, casting it to a trainStation object
        return Objects.equals(this.name, other.name);
    }
    
    /**
     * @param other we are checking if it is an instance of TrainStation. 
     * @return true if Other is an instance of TrainStation and the names match
     */
    

}
