package edu.merrimack.fop2.project2;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
/**
 * These tests should all pass when you are done with Part 1
 * 
 * @author Ed Grzyb
 */
public class DoubleLinkedListTest {
    
    public DoubleLinkedListTest() {
    }
    @Test
    public void testIsEmpty() {
        System.out.println("isEmpty");
        DoubleLinkedList instance = new DoubleLinkedList();
        boolean expResult = true;
        boolean result = instance.isEmpty();
        assertEquals(expResult, result);        
    }
    @Test
    public void testGetLengthEmpty() {
        System.out.println("getLength");
        DoubleLinkedList instance = new DoubleLinkedList();
        int expResult = 0;
        int result = instance.getLength();
        assertEquals(expResult, result);        
    }
    @Test
    public void testInsert() {
        System.out.println("insert");
        int index = 0;
        String entry = "First";
        DoubleLinkedList<String> instance = new DoubleLinkedList<>();
        boolean expResult = true;
        boolean result = instance.insert(index, entry);
        assertEquals(expResult, result);
        assertEquals("First", instance.getEntry(0));
        assertEquals(1, instance.getLength());
    }
    @Test
    public void testRemove() {
        System.out.println("remove");
        int index = 0;
        DoubleLinkedList<String> instance = new DoubleLinkedList<>();
        String entry = "Delete Me";
        boolean result = instance.insert(index, entry);
        result = instance.insert(index, "Not Me");
        boolean expResult = true;
        result = instance.remove(index);
        assertEquals(expResult, result);        
    }
    @Test
    public void testClear() {
        System.out.println("clear");
        DoubleLinkedList<String> instance = new DoubleLinkedList<>();
        instance.insert(0, "First"); 
        instance.insert(1, "Second"); 
        instance.insert(2, "Third");
        instance.clear();
        System.out.println("AFTER testClear:" + instance.toString());
        assertEquals(0,instance.getLength());
    }
    @Test
    public void testContains() {
        System.out.println("contains");
        DoubleLinkedList<String> instance = new DoubleLinkedList<>();
        instance.insert(0, "First"); 
        instance.insert(1, "Second"); 
        instance.insert(2, "Third");
        assertTrue(instance.contains("Second"));
    }
    @Test
    public void testGetEntry() {
        System.out.println("getEntry");
        int index = 0;
        String entry = "First";
        DoubleLinkedList<String> instance = new DoubleLinkedList<>();
        boolean result = instance.insert(index, entry);
        String expResult = "First";
        String resultString = instance.getEntry(index);
        assertEquals(expResult, resultString);
    }
    @Test
    public void testReplace() {
        System.out.println("replace");
        int index = 0;
        String entry = "First";
        DoubleLinkedList<String> instance = new DoubleLinkedList<>();
        boolean result = instance.insert(index, entry);
        String replaceEntry = "Second";
        String expResult = "First";
        String resultString = instance.replace(index, replaceEntry);
        assertEquals(expResult, resultString);        
    }
    @Test
    public void testToArray() {
        System.out.println("toArray");
        DoubleLinkedList<String> instance = new DoubleLinkedList<>();
        boolean result = instance.insert(0, "First");        
        result = instance.insert(1, "Second");  
        Object[] expResult = {"First", "Second"};
        Object[] resultArray = instance.toArray();
        assertArrayEquals(expResult, resultArray);
   }
    @Test
    public void testFind() {
        System.out.println("testFind");
        String key = "First";
        DoubleLinkedList<String> instance = new DoubleLinkedList<>();
        instance.insert(0, "First"); 
        int expResult = 0;
        int result = instance.find(key);
        assertEquals(expResult, result);        
    }
    @Test
    public void testToString() {
        System.out.println("toString");
        DoubleLinkedList<String> instance = new DoubleLinkedList<>();
        instance.insert(0, "First"); 
        instance.insert(1, "Second"); 
        instance.insert(2, "Third");
        String expResult = "[0]: First\n" + "[1]: Second\n" + "[2]: Third\n";
        String result = instance.toString();
        assertEquals(expResult, result);
   }
    
    public void testFind2() {
        System.out.println("testFind");
        String key = "First";
        DoubleLinkedList<String> instance = new DoubleLinkedList<>();
        instance.insert(0, "First"); 
        int expResult = 0;
        int result = instance.find(key);
        assertEquals(expResult, result);        
    }

    
}
