package edu.merrimack.fop2.project2;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
/**
 * These tests should all pass when you are done with Part 1
 * 
 * @author Ed Grzyb
 */
public class DoubleNodeTest {
    
    public DoubleNodeTest() {
    }
    @Test
    public void testItem() {
        System.out.println("testItem");
        String item = "Item";
        DoubleNode<String> node = new DoubleNode<>();
        node.setItem(item);
        assertEquals("Item",node.getItem());
    }
    @Test
    public void testNext() {
        System.out.println("testNext");
        String item = "Item";
        String nextItem = "Next Item";
        DoubleNode<String> node = new DoubleNode<>();
        DoubleNode<String> nextNode = new DoubleNode<>();
        node.setItem(item);
        nextNode.setItem(nextItem);
        node.setNext(nextNode);
        assertEquals("Next Item", node.getNext().getItem());
    }
    @Test
    public void testPrevious() {
        System.out.println("testPrevious");
        String item = "Item";
        String previousItem = "Previous Item";
        DoubleNode<String> node = new DoubleNode<>();
        DoubleNode<String> previousNode = new DoubleNode<>();
        node.setItem(item);
        previousNode.setItem(previousItem);
        node.setPrevious(previousNode);
        assertEquals("Previous Item", node.getPrevious().getItem());
    }
    
}
