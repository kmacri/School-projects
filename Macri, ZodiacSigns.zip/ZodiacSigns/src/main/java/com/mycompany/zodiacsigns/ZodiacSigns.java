/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.zodiacsigns;
import java.util.Scanner; //Import scanner class

/*
 *This program takes a day and month as an integer fromt he user and converts it into a zodiac sign.
 *Author: Kyle Macri
 *macrik@merrimack.edu
 *CSC 6001 - Foundations of Programming 1
 *Programming project #3
 */



public class ZodiacSigns {

    /**
     * 
     * @param args 
     */
    
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in); //create a scanner object
        int month, day;
        System.out.println("Enter the month (1-12): "); //asks user for the month as an integer
        month = in.nextInt(); //stores user input as variable month
        System.out.println("Enter the day of the month (1-31): "); //asks user for the day
        day = in.nextInt(); //stores integer as variable day
        if (month > 12){ //if month enterd is greater than 12, dispay "invalid month and end function
            System.out.println("Invalid month");
            return;
        }else if (day >31) { //if day  enterd is greater than 31, dispay "invalid month and end function
            System.out.println("Invalid day of the month");
            return;
        }
        System.out.printf("The user entered %d as the month.", month);
        System.out.println();
        System.out.printf("The user entered %d as the day of the month.", day);
        System.out.println();
        computeZodiac(month, day); 
        
        
    }
    
    /**
     * This function will compute appropriate zodiac sign from user input month/day
     * Function checks to make sure user input is within an accepted range
     * @param inputMonth
     * @param inputDay 
     */
    
    public static void computeZodiac(int inputMonth, int inputDay) {
        if (inputMonth == 1 && inputDay >= 1 && inputDay <=19) { //Function checks to make sure user input is within an accepted range
            System.out.println("The Zodiac Sign is: Capricorn ");
        } else if (inputMonth == 1 && inputDay > 19 && inputDay <= 31) {
            System.out.println("The Zodauc Sign is: Aquarius ");
        } else if (inputMonth == 2 && inputDay >=1 && inputDay <=18) {
            System.out.println("The Zodiac Sign is Aquarius ");
        } else if (inputMonth == 2 && inputDay >=19 && inputDay <=29) {
            System.out.println("The Zodiac Sign is Pisces ");
        } else if (inputMonth == 3 && inputDay >=1 && inputDay <=20) {
            System.out.println("The Zodiac Sign is Pisces ");
        } else if (inputMonth == 3 && inputDay >=21 && inputDay <=31) {
            System.out.println("The Zodiac Sign is Aires ");
        } else if (inputMonth == 4 && inputDay >=1 && inputDay <=19) {
            System.out.println("The Zodiac Sign is Aires ");
        } else if (inputMonth == 4 && inputDay >=20 && inputDay <=30) {
            System.out.println("The Zodiac Sign is Taurus ");
        } else if (inputMonth == 5 && inputDay >=1 && inputDay <=20) {
            System.out.println("The Zodiac Sign is Taurus ");
        } else if (inputMonth == 5 && inputDay >=21 && inputDay <=31) {
            System.out.println("The Zodiac Sign is Gemini ");
        } else if (inputMonth == 6 && inputDay >=1 && inputDay <=20) {
            System.out.println("The Zodiac Sign is Gemini ");
        } else if (inputMonth == 6 && inputDay >=21 && inputDay <=30) {
            System.out.println("The Zodiac Sign is Cancer ");
        } else if (inputMonth == 7 && inputDay >=1 && inputDay <=22) {
            System.out.println("The Zodiac Sign is Cancer ");
        } else if (inputMonth == 7 && inputDay >=23 && inputDay <=31) {
            System.out.println("The Zodiac Sign is Leo ");
        } else if (inputMonth == 8 && inputDay >=1 && inputDay <=22) {
            System.out.println("The Zodiac Sign is Leo ");
        } else if (inputMonth == 8 && inputDay >=23 && inputDay <=31) {
            System.out.println("The Zodiac Sign is Virgo ");
        } else if (inputMonth == 9 && inputDay >=1 && inputDay <=22) {
            System.out.println("The Zodiac Sign is Virgo ");
        } else if (inputMonth == 9 && inputDay >=23 && inputDay <=30) {
            System.out.println("The Zodiac Sign is Libra ");
        } else if (inputMonth == 10 && inputDay >=1 && inputDay <=22) {
            System.out.println("The Zodiac Sign is Libra ");
        } else if (inputMonth == 10 && inputDay >=23 && inputDay <=31) {
            System.out.println("The Zodiac Sign is Scorpio ");
        } else if (inputMonth == 11 && inputDay >=1 && inputDay <=21) {
            System.out.println("The Zodiac Sign is Scorpio ");
        } else if (inputMonth == 11 && inputDay >=22 && inputDay <=30) {
            System.out.println("The Zodiac Sign is Saggittarius ");
        } else if (inputMonth == 12 && inputDay >=1 && inputDay <=21) {
            System.out.println("The Zodiac Sign is Saggittarius ");
        } else if (inputMonth == 12 && inputDay >=22 && inputDay <=31) {
            System.out.println("The Zodiac Sign is Capricorn ");
        } else {
            System.out.print("Invalid calandar date");       // if date not in range, print invalid 
                 
        }     
            
            
        

}




}
